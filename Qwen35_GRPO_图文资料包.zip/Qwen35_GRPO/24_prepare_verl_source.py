"""Record the single NumPy metadata adaptation before manual VERL installation."""

import difflib
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile


W = Path('/data1/f00951948_cann91')
ARCHIVE_SHA256 = '3e03d8816b2546b2c5580705671b8d0bb3f79b8364e7b5c56dbfc1245536ba22'


def main():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    archive = W / 'packages/23_verl_sources/verl-0.9.1.tar.gz'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == ARCHIVE_SHA256, '源码压缩包校验失败'
    with tarfile.open(archive) as tf:
        original = tf.extractfile('verl-0.9.1/setup.py').read().decode()
    old, new = '"numpy>=2.0.0"', '"numpy>=1.26.4,<2.0.0"'
    assert original.count(old) == 1, '上游依赖声明与预期不同，停止修改'
    patched = original.replace(old, new)
    source = W / 'src/verl-0.9.1'
    setup_file = source / 'setup.py'
    assert setup_file.read_text() in (original, patched), 'setup.py 已有其他修改，停止覆盖'
    assert (source / 'verl/version/version').read_text().strip() == '0.9.1'
    records = W / 'records'
    backup = records / '24_setup.py.original'
    if backup.exists():
        assert backup.read_text() == original, '已有备份内容不同，停止覆盖'
    else:
        backup.write_text(original)
    diff = ''.join(difflib.unified_diff(
        original.splitlines(keepends=True), patched.splitlines(keepends=True),
        fromfile='upstream/setup.py', tofile='npu-local/setup.py',
    ))
    (records / '24_numpy_metadata.patch').write_text(diff)
    setup_file.write_text(patched)
    (records / '24_source_adaptation.json').write_text(json.dumps({
        'version': '0.9.1',
        'source_directory': str(source),
        'archive_sha256': ARCHIVE_SHA256,
        'original_setup_sha256': hashlib.sha256(original.encode()).hexdigest(),
        'adapted_setup_sha256': hashlib.sha256(patched.encode()).hexdigest(),
        'change': 'Base NumPy requirement: >=2.0.0 -> >=1.26.4,<2.0.0',
        'scope': 'Local NPU installation metadata; no training algorithm changes.',
    }, ensure_ascii=False, indent=2) + '\n')
    print('源码压缩包 SHA256 校验通过')
    print(diff, end='')
    print('VERL NumPy 依赖声明适配完成，原文件及差异已记录')


if __name__ == '__main__':
    main()
