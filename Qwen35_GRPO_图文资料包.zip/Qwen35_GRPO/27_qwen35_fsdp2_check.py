"""User-run one-step FSDP2 training check using the local Qwen3.5 weights.

Run with eight torchrun workers. This uses synthetic short text and writes
diagnostic JSON only. It does not save updated model weights.
"""

from datetime import datetime, timedelta, timezone
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
import sys
import time


W = Path('/data1/f00951948_cann91')
MODEL_PATH = W / 'models/Qwen3.5-0.8B'
TRACKED_PARAMETER = 'model.language_model.layers.0.linear_attn.out_proj.weight'


def main():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '0,1,2,3,4,5,6,7'
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'

    import torch
    import torch.distributed as dist
    import torch_npu  # noqa: F401
    from torch.distributed.device_mesh import init_device_mesh
    from torch.distributed.fsdp import FSDPModule, MixedPrecisionPolicy
    from torch.distributed.tensor import DTensor, Shard
    from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration
    from verl.utils.fsdp_utils import apply_fsdp2, fsdp2_clip_grad_norm_

    rank = int(os.environ['RANK'])
    local_rank = int(os.environ['LOCAL_RANK'])
    world_size = int(os.environ['WORLD_SIZE'])
    assert world_size == 8 and torch.npu.device_count() == 8
    torch.npu.set_device(local_rank)
    torch.npu.config.allow_internal_format = False
    torch.set_num_threads(4)
    torch.manual_seed(42)
    device = torch.device(f'npu:{local_rank}')
    run_key = os.environ['MASTER_PORT']
    run_dir = W / 'records' / f'27_fsdp2_{run_key}'
    run_dir.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()

    try:
        print(f'Rank {rank}：初始化 HCCL / FSDP2，设备={device}', flush=True)
        dist.init_process_group('hccl', init_method='env://', timeout=timedelta(seconds=600))
        mesh = init_device_mesh('npu', (world_size,), mesh_dim_names=('fsdp',))
        torch.npu.reset_peak_memory_stats()

        print(f'Rank {rank}：从本地加载 FP32 主权重……', flush=True)
        tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True)
        model = Qwen3_5ForConditionalGeneration.from_pretrained(
            str(MODEL_PATH),
            dtype=torch.float32,
            attn_implementation='eager',
            local_files_only=True,
        )
        model.config.use_cache = False
        model.config.text_config.use_cache = False
        # The target GSM8K task is text-only; the visual branch is not optimized.
        model.model.visual.requires_grad_(False)
        model.train()
        global_trainable_numel = sum(p.numel() for p in model.parameters() if p.requires_grad)

        apply_fsdp2(
            model,
            {
                'mesh': mesh,
                'reshard_after_forward': True,
                'mp_policy': MixedPrecisionPolicy(
                    param_dtype=torch.bfloat16,
                    reduce_dtype=torch.float32,
                    cast_forward_inputs=True,
                ),
            },
            {'wrap_policy': {'transformer_layer_cls_to_wrap': ['Qwen3_5DecoderLayer']}},
        )
        assert isinstance(model, FSDPModule)
        tracked = dict(model.named_parameters())[TRACKED_PARAMETER]
        assert isinstance(tracked, DTensor), '目标参数未转换为 DTensor'
        assert tracked.dtype == torch.float32, '主权重精度不是 FP32'
        assert len(tracked.placements) == 1 and isinstance(tracked.placements[0], Shard)
        assert tracked.placements[0].dim == 0
        before = tracked.detach().to_local().clone()
        assert before.numel() * world_size == tracked.numel(), '未确认参数按八卡分片'
        print(
            f'Rank {rank}：FSDP2分片完成，目标参数全局形状={tuple(tracked.shape)}，'
            f'本地形状={tuple(before.shape)}', flush=True,
        )

        trainable = [p for p in model.parameters() if p.requires_grad]
        optimizer = torch.optim.AdamW(
            trainable, lr=1e-5, betas=(0.9, 0.999),
            weight_decay=0.0, foreach=False, fused=False,
        )
        text = f'Question: What is {rank + 1} + 1?\nAnswer: {rank + 2}.\n'
        batch = tokenizer(text, return_tensors='pt', truncation=True, max_length=64)
        batch = {k: v.to(device) for k, v in batch.items()}
        optimizer.zero_grad(set_to_none=True)

        print(f'Rank {rank}：开始 BF16 前向和反向……', flush=True)
        output = model(**batch, labels=batch['input_ids'].clone(), use_cache=False)
        loss = output.loss
        local_loss = float(loss.detach().float().cpu().item())
        assert math.isfinite(local_loss), f'Rank {rank} Loss 非有限：{local_loss}'
        loss.backward()
        assert tracked.grad is not None, '目标参数没有梯度'

        # VERL uses this helper for the trainable parameters' global pre-clip norm.
        grad_norm = fsdp2_clip_grad_norm_(
            trainable, max_norm=1.0, error_if_nonfinite=True, foreach=False,
        )
        if isinstance(grad_norm, DTensor):
            grad_norm = grad_norm.full_tensor()
        global_grad_norm = float(grad_norm.detach().float().cpu().item())
        assert math.isfinite(global_grad_norm) and global_grad_norm > 0, global_grad_norm

        print(f'Rank {rank}：Loss={local_loss:.6f}，裁剪前全局梯度范数={global_grad_norm:.6f}', flush=True)
        optimizer.step()
        after = tracked.detach().to_local()
        delta = after.float() - before.float()
        delta_sq = delta.square().sum()
        delta_max = delta.abs().max()
        dist.all_reduce(delta_sq, op=dist.ReduceOp.SUM)
        dist.all_reduce(delta_max, op=dist.ReduceOp.MAX)
        global_delta_norm = math.sqrt(float(delta_sq.cpu().item()))
        global_delta_max = float(delta_max.cpu().item())
        assert math.isfinite(global_delta_norm) and global_delta_norm > 0, '未观察到目标参数更新'
        assert math.isfinite(global_delta_max) and global_delta_max > 0

        mean_loss = loss.detach().float().clone()
        dist.all_reduce(mean_loss, op=dist.ReduceOp.SUM)
        mean_loss /= world_size
        torch.npu.synchronize()
        result = {
            'rank': rank,
            'run_key': run_key,
            'device': str(device),
            'loss_type': 'synthetic short-text causal cross entropy',
            'local_loss': local_loss,
            'mean_rank_loss': float(mean_loss.cpu().item()),
            'global_pre_clip_grad_norm': global_grad_norm,
            'grad_norm_scope': 'all trainable text parameters; visual branch frozen',
            'clip_max_norm': 1.0,
            'global_trainable_numel': global_trainable_numel,
            'tracked_parameter': TRACKED_PARAMETER,
            'tracked_global_shape': list(tracked.shape),
            'tracked_local_shape': list(before.shape),
            'tracked_global_update_l2': global_delta_norm,
            'tracked_global_update_max_abs': global_delta_max,
            'master_param_dtype': str(tracked.dtype),
            'forward_param_dtype': 'torch.bfloat16',
            'optimizer_steps': 1,
            'learning_rate': 1e-5,
            'torch_allocator_peak_allocated_mb': torch.npu.max_memory_allocated() / 1024**2,
            'elapsed_seconds': round(time.monotonic() - started, 2),
            'passed': True,
        }
        (run_dir / f'rank_{rank}.json').write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        )
        print(f'Rank {rank}：参数更新检查通过，目标参数全局变化L2={global_delta_norm:.8g}', flush=True)
        dist.barrier()
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()

    if rank == 0:
        reports = [json.loads((run_dir / f'rank_{r}.json').read_text()) for r in range(world_size)]
        assert all(r['passed'] and r['run_key'] == run_key for r in reports)
        report = {
            'time_utc': datetime.now(timezone.utc).isoformat(),
            'world_size': world_size,
            'versions': {n: metadata.version(n) for n in ['torch', 'torch_npu', 'transformers', 'verl']},
            'model_path': str(MODEL_PATH),
            'model_weights_saved': False,
            'scope': 'One synthetic cross-entropy optimizer step; not GRPO or model-quality evaluation.',
            'rank_results': reports,
            'passed': True,
        }
        (W / 'records/27_fsdp2_check.json').write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        )
        print('Qwen3.5-0.8B八卡FSDP2前向、反向及参数更新检查通过', flush=True)


if __name__ == '__main__':
    main()
