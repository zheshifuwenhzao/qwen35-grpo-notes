"""Run inside the user's verl91 container after step 23 installation."""

import importlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys


WORKSPACE = Path('/data1/f00951948_cann91')
PREFIX = WORKSPACE / 'envs/verl91'


def main():
    assert Path('/.dockerenv').is_file(), '当前不在 Docker 容器内'
    assert Path(sys.prefix) == PREFIX, f'Python 环境错误：{sys.prefix}'
    assert os.environ.get('CONDA_PREFIX') == str(PREFIX), '未激活 verl91'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['HF_DATASETS_OFFLINE'] = '1'
    os.environ['WANDB_MODE'] = 'disabled'

    records = WORKSPACE / 'records'
    expected = json.loads((records / '21_core_before.json').read_text())
    expected.update(json.loads((records / '23_protected_versions.json').read_text()))
    for line in (records / '23_verl_deps.lock.txt').read_text().splitlines():
        if line.strip() and not line.startswith('#'):
            name, version = line.split('==', 1)
            expected[name] = version
    for name, version in expected.items():
        actual = metadata.version(name)
        assert actual == version, f'{name} 版本错误：{actual}，预期 {version}'
    print('核心版本及本步锁定版本检查通过', flush=True)

    for name in (
        'torch', 'torch-npu', 'numpy', 'transformers', 'vllm', 'vllm-ascend',
        'ray', 'accelerate', 'peft', 'tensordict', 'torchdata', 'TransferQueue',
        'datasets', 'pyarrow', 'fsspec', 'packaging', 'tensorboard',
        'opentelemetry-exporter-prometheus',
    ):
        print(f'{name}：{metadata.version(name)}', flush=True)

    import torch
    import torch_npu  # noqa: F401
    from torch.distributed.fsdp import fully_shard
    from torchdata.stateful_dataloader import StatefulDataLoader
    from tensordict import TensorDict

    assert callable(fully_shard)
    td = TensorDict({'value': torch.arange(2)}, batch_size=[2])
    assert td['value'].tolist() == [0, 1]
    loader = StatefulDataLoader(torch.utils.data.TensorDataset(torch.arange(4)), batch_size=2)
    assert next(iter(loader))[0].tolist() == [0, 1]
    assert isinstance(loader.state_dict(), dict)
    print('FSDP2 接口、TensorDict 和 StatefulDataLoader 检查通过', flush=True)

    for module in (
        'ray', 'accelerate', 'peft', 'hydra', 'omegaconf', 'transfer_queue',
        'qwen_vl_utils', 'wandb', 'opentelemetry.exporter.prometheus',
    ):
        importlib.import_module(module)
    print('Ray / PEFT / TransferQueue 等训练依赖导入通过', flush=True)

    from datasets import Dataset, load_dataset
    from torch.utils.tensorboard import SummaryWriter

    check_dir = WORKSPACE / 'tmp/23_dependency_check'
    check_dir.mkdir(parents=True, exist_ok=True)
    samples = [{'question': '1+1', 'answer': '2'}, {'question': '3*5', 'answer': '15'}]
    parquet_file = check_dir / 'samples.parquet'
    Dataset.from_list(samples).to_parquet(str(parquet_file))
    reloaded = load_dataset(
        'parquet', data_files=str(parquet_file), split='train',
        cache_dir=str(WORKSPACE / '.cache/datasets'),
    )
    assert list(reloaded['answer']) == ['2', '15']
    print('Datasets / PyArrow 本地 Parquet 写入和读取通过', flush=True)

    event_dir = check_dir / 'tensorboard'
    with SummaryWriter(log_dir=str(event_dir)) as writer:
        writer.add_scalar('environment_check/dependency_import_ok', 1.0, 0)
        writer.flush()
    assert list(event_dir.glob('events.out.tfevents.*'))
    print('TensorBoard 环境检查事件写入通过（此项不是模型训练指标）', flush=True)

    from vllm import LLM, SamplingParams
    from vllm.platforms import current_platform

    assert LLM is not None and SamplingParams is not None
    assert type(current_platform).__name__ == 'NPUPlatform', str(type(current_platform))
    print('vLLM 推理接口及 NPU 平台识别保持正常', flush=True)

    installed = {dist.metadata['Name']: dist.version for dist in metadata.distributions()}
    (records / '23_after_packages.json').write_text(
        json.dumps(installed, ensure_ascii=False, indent=2) + '\n'
    )
    print('VERL训练依赖安装检查通过', flush=True)


if __name__ == '__main__':
    main()
