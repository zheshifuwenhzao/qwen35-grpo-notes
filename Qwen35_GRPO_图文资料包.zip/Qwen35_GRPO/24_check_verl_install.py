"""Validate the user's editable VERL install without launching training or Ray."""

import importlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys


W = Path('/data1/f00951948_cann91')
SOURCE = W / 'src/verl-0.9.1'


def check_components(source):
    import numpy as np
    import torch
    import torch_npu  # noqa: F401
    import verl
    from hydra import compose, initialize_config_dir
    from omegaconf import OmegaConf
    from torch.distributed.fsdp import fully_shard
    from verl import DataProto
    from verl.trainer.ppo.core_algos import compute_grpo_outcome_advantage
    from verl.utils.device import get_device_name
    from verl.utils.fsdp_utils import apply_fsdp2

    assert Path(verl.__file__).resolve().is_relative_to(source.resolve())
    assert verl.__version__ == '0.9.1'
    assert get_device_name() == 'npu', get_device_name()
    print('VERL 版本：', verl.__version__, flush=True)
    print('VERL 源码位置：', verl.__file__, flush=True)
    print('VERL 设备类型：', get_device_name(), flush=True)

    for module in (
        'verl.trainer.main_ppo',
        'verl.workers.engine.fsdp',
        'verl.models.transformers.qwen3_5',
        'verl.workers.rollout.vllm_rollout.vllm_async_server',
    ):
        print('检查模块：', module, flush=True)
        importlib.import_module(module)
    assert callable(fully_shard) and callable(apply_fsdp2)
    print('训练入口、FSDP2 接口、Qwen3.5 适配和 vLLM Rollout 模块导入通过', flush=True)

    # A small CPU-only integration check; no model or optimizer is constructed.
    group = np.array(['same_question', 'same_question'], dtype=object)
    batch = DataProto.from_dict(
        tensors={'input_ids': torch.tensor([[1, 2], [1, 3]])},
        non_tensors={'uid': group},
    )
    assert len(batch) == 2
    advantages, returns = compute_grpo_outcome_advantage(
        token_level_rewards=torch.tensor([[0.0, 1.0], [0.0, 0.0]]),
        response_mask=torch.ones(2, 2),
        index=group,
    )
    assert torch.isfinite(advantages).all()
    assert torch.all(advantages[0] > 0) and torch.all(advantages[1] < 0)
    assert torch.allclose(advantages.mean(dim=0), torch.zeros(2), atol=1e-6)
    assert torch.equal(advantages, returns)
    print('DataProto 与 GRPO 分组优势计算检查通过（CPU 功能检查）', flush=True)

    with initialize_config_dir(version_base=None, config_dir=str(source / 'verl/trainer/config')):
        cfg = compose(config_name='ppo_trainer', overrides=[
            'algorithm.adv_estimator=grpo',
            'actor_rollout_ref.actor.strategy=fsdp2',
            'actor_rollout_ref.actor.fsdp_config.strategy=fsdp2',
            'actor_rollout_ref.ref.strategy=fsdp2',
            'actor_rollout_ref.ref.fsdp_config.strategy=fsdp2',
            'actor_rollout_ref.rollout.name=vllm',
            'actor_rollout_ref.model.path=' + str(W / 'models/Qwen3.5-0.8B'),
            'trainer.device=npu',
        ])
    assert cfg.algorithm.adv_estimator == 'grpo'
    assert cfg.actor_rollout_ref.actor.strategy == 'fsdp2'
    assert cfg.actor_rollout_ref.actor.fsdp_config.strategy == 'fsdp2'
    assert cfg.actor_rollout_ref.rollout.name == 'vllm'
    assert cfg.trainer.device == 'npu'
    OmegaConf.save(cfg, str(W / 'records/24_grpo_config_preview.yaml'), resolve=False)
    print('GRPO / FSDP2 / vLLM / NPU 配置组合通过', flush=True)
    print('配置预览已保存；尚未设置正式训练的数据路径和训练参数', flush=True)


def main():
    assert Path('/.dockerenv').is_file(), '当前不在 Docker 容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['WANDB_MODE'] = 'disabled'
    assert metadata.version('verl') == '0.9.1'
    direct = json.loads(metadata.distribution('verl').read_text('direct_url.json'))
    assert direct.get('dir_info', {}).get('editable') is True, 'VERL 未以 editable 源码方式安装'

    records = W / 'records'
    expected = json.loads((records / '21_core_before.json').read_text())
    expected.update(json.loads((records / '23_protected_versions.json').read_text()))
    for line in (records / '23_verl_deps.lock.txt').read_text().splitlines():
        if line.strip() and not line.startswith('#'):
            name, version = line.split('==', 1)
            expected[name] = version
    for name, version in expected.items():
        assert metadata.version(name) == version, f'{name} 版本发生变化'
    print('现有核心版本与训练依赖保持不变', flush=True)

    check_components(SOURCE)
    (records / '24_verl_install_check.json').write_text(json.dumps({
        'verl': metadata.version('verl'),
        'source_directory': str(SOURCE),
        'editable': True,
        'protected_versions': expected,
        'component_imports_passed': True,
        'cpu_grpo_advantage_check_passed': True,
        'hydra_config_composition_passed': True,
        'distributed_training_tested': False,
    }, ensure_ascii=False, indent=2) + '\n')
    print('VERL源码安装及基础接口检查通过', flush=True)


if __name__ == '__main__':
    main()
