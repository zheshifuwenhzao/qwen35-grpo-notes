"""User-run eight-NPU collectives check, launched with torch.distributed.run."""

from datetime import datetime, timedelta, timezone
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import re
import subprocess
import sys


W = Path('/data1/f00951948_cann91')


def guard():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '0,1,2,3,4,5,6,7'


def preflight():
    p = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=30)
    info = p.stdout + p.stderr
    (W / 'logs/26_npu_before_hccl.log').write_text(info)
    assert p.returncode == 0, info
    idle = {int(x) for x in re.findall(r'No running processes found in NPU\s+(\d+)', info)}
    if idle != set(range(8)):
        print(info, flush=True)
        raise RuntimeError('未确认八张卡均无运行进程，停止启动通信检查，请查看上方进程信息')
    print('启动前检查：八张 NPU 均未显示运行进程', flush=True)


def distributed_check():
    import torch
    import torch.distributed as dist
    import torch_npu  # noqa: F401

    rank = int(os.environ['RANK'])
    local_rank = int(os.environ['LOCAL_RANK'])
    world_size = int(os.environ['WORLD_SIZE'])
    assert world_size == 8, f'预期8个进程，实际为{world_size}'
    assert torch.npu.device_count() == 8
    torch.npu.set_device(local_rank)
    device = torch.device(f'npu:{local_rank}')
    print(f'Rank {rank}：绑定 {device}，开始初始化 HCCL', flush=True)
    checks = []
    try:
        dist.init_process_group('hccl', init_method='env://', timeout=timedelta(seconds=600))
        assert dist.get_backend() == 'hccl'
        expected_sum = world_size * (world_size + 1) // 2

        for dtype in (torch.float32, torch.bfloat16):
            tensor = torch.full((16,), rank + 1, dtype=dtype, device=device)
            dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
            assert torch.all(tensor.cpu().float() == expected_sum), (rank, dtype, tensor.cpu())
            checks.append(f'all_reduce_{dtype}')

        for dtype in (torch.float32, torch.bfloat16):
            local = torch.full((16,), rank + 1, dtype=dtype, device=device)
            gathered = torch.empty(world_size * 16, dtype=dtype, device=device)
            dist.all_gather_into_tensor(gathered, local)
            expected = torch.arange(1, world_size + 1, dtype=torch.float32).view(-1, 1).expand(-1, 16)
            assert torch.equal(gathered.cpu().float().view(world_size, 16), expected)
            checks.append(f'all_gather_into_tensor_{dtype}')

        for dtype in (torch.float32, torch.bfloat16):
            source = torch.full((world_size * 16,), rank + 1, dtype=dtype, device=device)
            reduced = torch.empty(16, dtype=dtype, device=device)
            dist.reduce_scatter_tensor(reduced, source, op=dist.ReduceOp.SUM)
            assert torch.all(reduced.cpu().float() == expected_sum), (rank, dtype, reduced.cpu())
            checks.append(f'reduce_scatter_tensor_{dtype}')

        broadcast = torch.arange(16, dtype=torch.float32, device=device) if rank == 0 else torch.zeros(
            16, dtype=torch.float32, device=device
        )
        dist.broadcast(broadcast, src=0)
        assert torch.equal(broadcast.cpu(), torch.arange(16, dtype=torch.float32))
        checks.append('broadcast_float32')
        torch.npu.synchronize()
        dist.barrier()
        print(f'Rank {rank}：全部集合通信结果正确，AllReduce结果={expected_sum}', flush=True)
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()

    if rank == 0:
        (W / 'records/26_hccl_check.json').write_text(json.dumps({
            'time_utc': datetime.now(timezone.utc).isoformat(),
            'torch': metadata.version('torch'),
            'torch_npu': metadata.version('torch_npu'),
            'backend': 'hccl',
            'world_size': world_size,
            'checks': checks,
            'expected_all_reduce_sum': expected_sum,
            'scope': 'Small-tensor collective correctness; no model training or throughput benchmark.',
            'passed': True,
        }, ensure_ascii=False, indent=2) + '\n')
        print('八卡HCCL集合通信检查通过', flush=True)


if __name__ == '__main__':
    guard()
    if sys.argv[1:] == ['--preflight']:
        preflight()
    elif not sys.argv[1:]:
        distributed_check()
    else:
        raise SystemExit('用法：--preflight 检查当前卡占用；无参数时由 torchrun 启动通信检查')
