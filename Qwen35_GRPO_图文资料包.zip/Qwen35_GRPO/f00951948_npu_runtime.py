"""Runtime options used by the verified step-27 FSDP2 check; no model patches."""

import torch
import torch_npu  # noqa: F401

torch.npu.config.allow_internal_format = False
torch.set_num_threads(4)
