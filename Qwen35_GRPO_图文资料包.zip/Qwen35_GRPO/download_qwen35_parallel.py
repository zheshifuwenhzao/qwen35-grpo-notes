"""Download the pinned official Qwen3.5-0.8B checkpoint with HTTP ranges.

Uses a separate sparse file, resumes completed chunks, and verifies the full
official SHA256 before publishing. The original curl download is untouched.
"""

import concurrent.futures
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import threading
import time
import urllib.request


BASE = Path('/data1/f00951948_cann91')
MODEL = 'Qwen/Qwen3.5-0.8B'
REVISION = 'c62d4afcf135a7464a3e6743ee9454a6997291a1'
NAME = 'model.safetensors-00001-of-00001.safetensors'
SIZE = 1746942600
EXPECTED = '04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696'
URL = f'https://modelscope.cn/models/{MODEL}/resolve/{REVISION}/{NAME}'
CHUNK = 16 * 1024 * 1024
WORKERS = 16
DIRECTORY = BASE / 'models/Qwen3.5-0.8B'
FINAL = DIRECTORY / NAME
TEMP = DIRECTORY / (NAME + '.parallel.part')
ORIGINAL = DIRECTORY / (NAME + '.part')
STATE = BASE / 'records/14_qwen35_parallel_state.json'
REQUIRED = {
    'LICENSE', 'config.json', 'chat_template.jinja', 'merges.txt',
    'vocab.json', 'tokenizer.json', 'tokenizer_config.json',
    'preprocessor_config.json', 'video_preprocessor_config.json',
    'model.safetensors.index.json', NAME,
}


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            result.update(data)
    return result.hexdigest()


def write_all(fd, data, offset):
    view = memoryview(data)
    while view:
        size = os.pwrite(fd, view, offset)
        if size <= 0:
            raise OSError('Failed to write downloaded data')
        view = view[size:]
        offset += size


def verify_all(weight_digest):
    document = json.loads(
        (BASE / 'records/14_qwen35_modelscope_manifest.json').read_text()
    )
    assert document['revision'] == REVISION
    entries = {item['Path']: item for item in document['manifest']['Data']['Files']}
    verified = []
    for name in sorted(REQUIRED):
        path = DIRECTORY / name
        assert path.is_file(), f'Missing model file: {name}'
        assert path.stat().st_size == entries[name]['Size'], f'Wrong size: {name}'
        actual = weight_digest if name == NAME else digest(path)
        assert actual == entries[name]['Sha256'], f'SHA256 mismatch: {name}'
        verified.append({'file': name, 'bytes': path.stat().st_size, 'sha256': actual})
    index = json.loads((DIRECTORY / 'model.safetensors.index.json').read_text())
    assert set(index['weight_map'].values()) <= REQUIRED
    return verified


def main():
    assert Path('/.dockerenv').exists(), 'Run inside f00951948_cann91'
    assert sys.prefix == str(BASE / 'envs/verl91'), 'Use the verl91 Python interpreter'
    DIRECTORY.mkdir(parents=True, exist_ok=True)
    (BASE / 'records').mkdir(exist_ok=True)
    lock_file = (BASE / 'records/14_qwen35_parallel.lock').open('a')
    fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    started = time.monotonic()
    count = math.ceil(SIZE / CHUNK)
    completed = set()
    copied_prefix = 0

    if FINAL.exists() and FINAL.stat().st_size == SIZE and digest(FINAL) == EXPECTED:
        print(json.dumps({'already_verified': True, 'files': verify_all(EXPECTED)}), flush=True)
        return

    if TEMP.exists():
        assert STATE.exists(), 'Temporary file exists without a checkpoint'
        state = json.loads(STATE.read_text())
        assert (state['sha256'], state['bytes'], state['chunk_bytes']) == (EXPECTED, SIZE, CHUNK)
        assert TEMP.stat().st_size == SIZE
        completed = set(state['completed_chunks'])
        assert completed <= set(range(count)), 'Invalid completed chunk list'
        copied_prefix = state.get('copied_prefix_bytes', 0)
        fd = os.open(TEMP, os.O_RDWR)
    else:
        fd = os.open(TEMP, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o644)
        os.ftruncate(fd, SIZE)
        if ORIGINAL.exists():
            copied_prefix = min(ORIGINAL.stat().st_size // CHUNK, SIZE // CHUNK) * CHUNK
            with ORIGINAL.open('rb') as source:
                offset = 0
                while offset < copied_prefix:
                    data = source.read(min(8 * 1024 * 1024, copied_prefix - offset))
                    assert data, 'Original partial file changed while copying'
                    write_all(fd, data, offset)
                    offset += len(data)
            completed = set(range(copied_prefix // CHUNK))

    mutex = threading.Lock()
    downloaded = sum(min(CHUNK, SIZE - i * CHUNK) for i in completed)
    initial = downloaded

    def checkpoint():
        state = {
            'model': MODEL, 'revision': REVISION, 'sha256': EXPECTED,
            'bytes': SIZE, 'chunk_bytes': CHUNK,
            'copied_prefix_bytes': copied_prefix,
            'completed_chunks': sorted(completed),
        }
        temporary = STATE.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(state, indent=2) + '\n')
        temporary.replace(STATE)

    checkpoint()
    request = urllib.request.Request(URL, headers={'Range': 'bytes=0-0'})
    with urllib.request.urlopen(request, timeout=30) as response:
        assert response.status == 206
        assert response.headers.get('Content-Range') == f'bytes 0-0/{SIZE}'
        assert len(response.read(1)) == 1
        direct = response.url

    def fetch(index):
        nonlocal downloaded
        position = index * CHUNK
        end = min(SIZE, position + CHUNK) - 1
        for attempt in range(5):
            try:
                request = urllib.request.Request(
                    direct, headers={'Range': f'bytes={position}-{end}'}
                )
                with urllib.request.urlopen(request, timeout=25) as response:
                    expected_range = f'bytes {position}-{end}/{SIZE}'
                    if response.status != 206 or response.headers.get('Content-Range') != expected_range:
                        raise RuntimeError('Server returned an unexpected HTTP range')
                    while position <= end:
                        data = response.read(min(1024 * 1024, end + 1 - position))
                        if not data:
                            raise EOFError('HTTP range ended early')
                        write_all(fd, data, position)
                        position += len(data)
                        with mutex:
                            downloaded += len(data)
                break
            except Exception as error:
                if position > end:
                    break
                if attempt == 4:
                    raise
                print(json.dumps({'retry_chunk': index, 'attempt': attempt + 1, 'error': str(error)}), flush=True)
                time.sleep(min(2 ** attempt, 10))
        assert position == end + 1
        with mutex:
            completed.add(index)
            checkpoint()

    print(json.dumps({'started': True, 'workers': WORKERS, 'reused_MB': round(initial / 1e6, 2)}), flush=True)
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
            pending = {pool.submit(fetch, index) for index in range(count) if index not in completed}
            while pending:
                ready, pending = concurrent.futures.wait(
                    pending, timeout=10,
                    return_when=concurrent.futures.FIRST_COMPLETED,
                )
                for future in ready:
                    future.result()
                elapsed = time.monotonic() - started
                with mutex:
                    current = downloaded
                rate = (current - initial) / max(elapsed, 0.001)
                print(json.dumps({
                    'downloaded_MB': round(current / 1e6, 2),
                    'total_MB': round(SIZE / 1e6, 2),
                    'percent': round(100 * current / SIZE, 1),
                    'MB_s': round(rate / 1e6, 2),
                    'eta_seconds': round((SIZE - current) / rate) if rate else None,
                }), flush=True)
        os.fsync(fd)
    finally:
        os.close(fd)

    actual = digest(TEMP)
    assert actual == EXPECTED, f'Full checkpoint SHA256 mismatch: {actual}'
    TEMP.replace(FINAL)
    verified = verify_all(actual)
    elapsed = time.monotonic() - started
    report = {
        'model': MODEL, 'revision': REVISION, 'source': URL,
        'workers': WORKERS, 'bytes': SIZE, 'sha256': actual,
        'seconds': round(elapsed, 2), 'reused_bytes': initial,
        'download_MB_s': round((SIZE - initial) / elapsed / 1e6, 3),
        'verified_files': verified,
    }
    (BASE / 'records/14_qwen35_parallel_download.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    )
    print(json.dumps({'complete': True, 'seconds': report['seconds'], 'sha256': actual, 'verified_files': len(verified)}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
