"""Compare complete, protocol-matched baseline/post-training GSM8K results."""

import argparse
import json
import os
from pathlib import Path
import sys


W = Path('/data1/f00951948_cann91')


def read_run(label):
    path = W / 'eval/gsm8k' / label
    metrics = json.loads((path / 'metrics.json').read_text())
    predictions = [json.loads(line) for line in (path / 'predictions.jsonl').read_text().splitlines() if line]
    assert metrics['complete'] and metrics['total_count'] == 1319 and len(predictions) == 1319
    by_id = {r['sample_id']: r for r in predictions}
    assert len(by_id) == 1319
    assert sum(r['score'] == 1.0 for r in predictions) == metrics['correct_count']
    return metrics, by_id


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    assert Path('/.dockerenv').is_file() and Path(sys.prefix) == W / 'envs/verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91')
    baseline, before = read_run('baseline')
    if args.prepare_only:
        print(f'基线记录检查通过：{baseline["correct_count"]}/1319，准确率{baseline["accuracy_percent"]:.2f}%', flush=True)
        print('等待导出模型完成同协议复测后再比较', flush=True)
        return
    after_metrics, after = read_run('grpo_step10')
    export = json.loads((W / 'records/31_grpo_export_check.json').read_text())
    assert export['passed'] and after_metrics['model_path'] == export['model_path']
    assert baseline['protocol_fingerprint'] == after_metrics['protocol_fingerprint'], '两次评测协议不同，停止直接比较'
    assert set(before) == set(after)
    improved, regressed = [], []
    for sample_id in before:
        b, a = before[sample_id], after[sample_id]
        assert b['question'] == a['question'] and b['ground_truth'] == a['ground_truth']
        if b['score'] == 0.0 and a['score'] == 1.0:
            improved.append(sample_id)
        if b['score'] == 1.0 and a['score'] == 0.0:
            regressed.append(sample_id)
    delta = 100 * (after_metrics['correct_count'] - baseline['correct_count']) / 1319
    from scipy.stats import binomtest

    discordant = len(improved) + len(regressed)
    paired_p = binomtest(len(improved), discordant, p=0.5).pvalue if discordant else 1.0
    result = {
        'baseline': baseline, 'after_grpo_step10': after_metrics,
        'accuracy_change_percentage_points': delta,
        'newly_correct_count': len(improved), 'newly_wrong_count': len(regressed),
        'newly_correct_sample_ids': improved, 'newly_wrong_sample_ids': regressed,
        'paired_exact_mcnemar_p_value': paired_p,
        'same_protocol_verified': True,
        'exported_model_reloaded_for_vllm_evaluation': True,
        'training_pipeline_acceptance_passed': True,
    }
    path = W / 'records/32_grpo_gsm8k_comparison.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(f'训练前：{baseline["correct_count"]}/1319，严格准确率={baseline["accuracy_percent"]:.2f}%', flush=True)
    print(f'训练后：{after_metrics["correct_count"]}/1319，严格准确率={after_metrics["accuracy_percent"]:.2f}%', flush=True)
    print(f'准确率变化：{delta:+.2f}个百分点', flush=True)
    print(f'由错变对：{len(improved)}题；由对变错：{len(regressed)}题', flush=True)
    print(f'格式符合率：{100*baseline["format_compliance_rate"]:.2f}% -> {100*after_metrics["format_compliance_rate"]:.2f}%', flush=True)
    print(f'回答截断比例：{100*baseline["truncation_rate"]:.2f}% -> {100*after_metrics["truncation_rate"]:.2f}%', flush=True)
    print(f'配对变化精确检验p值：{paired_p:.4g}', flush=True)
    print('对比记录：', path, flush=True)
    print('训练后同协议评测对比完成', flush=True)


if __name__ == '__main__':
    main()
