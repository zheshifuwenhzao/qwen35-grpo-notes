"""User-run offline preparation of GSM8K for VERL and reproducible evaluation.

Row schema and prompt instruction follow VERL v0.9.1's official example:
https://github.com/verl-project/verl/blob/v0.9.1/examples/data_preprocess/gsm8k.py
The installed official GSM8K scorer is used without modification.
"""

import hashlib
import json
import os
from pathlib import Path
import random
import sys


W = Path('/data1/f00951948_cann91')
D = W / 'data/gsm8k'
REVISION = '740312add88f781978c0658806c59bc2815b9866'
INSTRUCTION = 'Let\'s think step by step and output the final answer after "####".'
SEED = 42
VALIDATION_SIZE = 256
MAX_PROMPT_LENGTH = 1024
RAW_FILES = {
    'train': ('train-00000-of-00001.parquet', 'ea82612ea9582142387730c793eb67d3b12849002bc0b7fa6f8efafa7351419d'),
    'test': ('test-00000-of-00001.parquet', 'ee7b8da9e381df27b9e3f7758a159ab2bdaa4dbaa910546cbbc47e0cb44e4f59'),
}


def main():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_DATASETS_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'

    import pyarrow.parquet as pq
    from datasets import Dataset
    from omegaconf import OmegaConf
    from transformers import AutoTokenizer
    from verl.utils.dataset.rl_dataset import RLHFDataset
    from verl.utils.reward_score.gsm8k import compute_score, extract_solution

    raw = {}
    for split, (name, expected_hash) in RAW_FILES.items():
        p = D / 'raw' / name
        assert hashlib.sha256(p.read_bytes()).hexdigest() == expected_hash, f'原始文件校验失败：{name}'
        raw[split] = pq.read_table(p).to_pylist()
    assert len(raw['train']) == 7473 and len(raw['test']) == 1319
    assert not ({r['question'] for r in raw['train']} & {r['question'] for r in raw['test']})
    print('原始数据校验通过：训练集7473条，测试集1319条', flush=True)

    # Check the strict scorer on artificial examples, not model-generated answers.
    assert compute_score('Calculation complete.\n#### 72', '72', method='strict') == 1.0
    assert compute_score('Calculation complete.\n#### 73', '72', method='strict') == 0.0
    assert compute_score('72', '72', method='strict') == 0.0
    print('奖励函数人工样例检查通过：正确且格式匹配=1，错误或缺少格式=0', flush=True)

    val_indices = set(random.Random(SEED).sample(range(len(raw['train'])), VALIDATION_SIZE))
    train_indices = [i for i in range(len(raw['train'])) if i not in val_indices]
    assert not ({raw['train'][i]['question'] for i in train_indices} & {
        raw['train'][i]['question'] for i in val_indices
    }), '训练与验证题目发生重复，停止保存划分'

    def convert(example, source_split, index, output_split):
        answer = extract_solution(example['answer'], method='strict')
        assert answer is not None, f'{source_split}:{index} 无法提取标准答案'
        return {
            'data_source': 'openai/gsm8k',
            'prompt': [{'role': 'user', 'content': example['question'] + ' ' + INSTRUCTION}],
            'ability': 'math',
            'reward_model': {'style': 'rule', 'ground_truth': answer},
            'extra_info': {
                'split': output_split,
                'source_split': source_split,
                'index': index,
                'sample_id': f'{source_split}:{index}',
                'answer': example['answer'],
                'question': example['question'],
            },
        }

    rows = {
        'train': [convert(raw['train'][i], 'train', i, 'train') for i in train_indices],
        'val': [convert(raw['train'][i], 'train', i, 'validation') for i in sorted(val_indices)],
        'test': [convert(r, 'test', i, 'test') for i, r in enumerate(raw['test'])],
    }
    tokenizer = AutoTokenizer.from_pretrained(str(W / 'models/Qwen3.5-0.8B'), local_files_only=True)
    files, token_stats = {}, {}
    for split, items in rows.items():
        lengths = []
        for row in items:
            ids = tokenizer.apply_chat_template(
                row['prompt'], tokenize=True, add_generation_prompt=True,
                enable_thinking=False, return_dict=False,
            )
            lengths.append(len(ids))
        assert max(lengths) <= MAX_PROMPT_LENGTH, f'{split} 存在超长输入：{max(lengths)}'
        ordered = sorted(lengths)
        token_stats[split] = {
            'max': max(lengths), 'median': ordered[len(ordered) // 2],
            'p95': ordered[int((len(ordered) - 1) * 0.95)],
        }
        p = D / f'{split}.parquet'
        tmp = D / f'{split}.tmp.parquet'
        Dataset.from_list(items).to_parquet(str(tmp))
        tmp.replace(p)
        assert pq.read_metadata(p).num_rows == len(items)
        files[split] = {'path': str(p), 'rows': len(items), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
        print(f'{split}：{len(items)}条，最长Prompt={max(lengths)} tokens，已保存{p.name}', flush=True)

    # Verify the actual installed VERL loader can read the generated format.
    data_config = OmegaConf.create({
        'cache_dir': str(W / '.cache/verl/rlhf'),
        'prompt_key': 'prompt',
        'max_prompt_length': MAX_PROMPT_LENGTH,
        'return_raw_chat': True,
        'truncation': 'error',
        'filter_overlong_prompts': False,
        'filter_overlong_prompts_workers': 1,
        'apply_chat_template_kwargs': {'enable_thinking': False},
        'use_shm': False,
    })
    for split, info in files.items():
        loaded = RLHFDataset(data_files=[info['path']], tokenizer=tokenizer, config=data_config)
        assert len(loaded) == info['rows']
        sample = loaded[0]
        assert sample['data_source'] == 'openai/gsm8k'
        assert sample['raw_prompt'][0]['content'] == rows[split][0]['prompt'][0]['content']
        assert sample['reward_model']['ground_truth'] == rows[split][0]['reward_model']['ground_truth']
        print(f'VERL数据加载检查通过：{split}，{len(loaded)}条', flush=True)

    raw_manifest = json.loads((W / 'records/28_gsm8k_raw_manifest.json').read_text())
    assert raw_manifest['revision'] == REVISION
    summary = {
        'dataset': 'openai/gsm8k', 'config': 'main', 'revision': REVISION,
        'split_seed': SEED,
        'validation_source': '256 rows held out from the official training split',
        'validation_source_indices': sorted(val_indices),
        'test_source': 'entire official test split; excluded from training and checkpoint selection',
        'files': files, 'prompt_token_stats': token_stats,
        'instruction': INSTRUCTION,
        'apply_chat_template_kwargs': {'enable_thinking': False},
        'max_prompt_length': MAX_PROMPT_LENGTH,
        'planned_max_response_length': 1024,
        'reward_scorer': 'verl.utils.reward_score.gsm8k.compute_score',
        'reward_method': 'strict',
        'raw_files': raw_manifest['files'],
        'verl_dataset_loader_check_passed': True,
        'passed': True,
    }
    (W / 'records/28_gsm8k_data_check.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    preview = {
        'example': rows['train'][0],
        'rendered_prompt': tokenizer.apply_chat_template(
            rows['train'][0]['prompt'], tokenize=False,
            add_generation_prompt=True, enable_thinking=False,
        ),
    }
    (W / 'records/28_gsm8k_sample.json').write_text(json.dumps(preview, ensure_ascii=False, indent=2) + '\n')
    print('划分完成：训练7217条 / 验证256条 / 测试1319条', flush=True)
    print('GSM8K数据准备及奖励规则检查通过', flush=True)


if __name__ == '__main__':
    main()
