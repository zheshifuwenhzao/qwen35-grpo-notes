"""Single-NPU text-generation smoke check; run manually inside verl91."""

import json
import time
from importlib import metadata
from pathlib import Path


def main():
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    from vllm.platforms import current_platform

    workspace = Path("/data1/f00951948_cann91")
    model_path = workspace / "models/Qwen3.5-0.8B"
    result_path = workspace / "records/22_qwen35_vllm_result.json"

    expected = json.loads(
        (workspace / "records/21_core_before.json").read_text()
    )
    expected["vllm-ascend"] = "0.23.0.post1"
    versions = {name: metadata.version(name) for name in expected}
    assert versions == expected, f"核心版本与预期不一致：{versions}"
    assert current_platform.device_type == "npu", "未识别为NPU平台"

    index = json.loads((model_path / "model.safetensors.index.json").read_text())
    for filename in set(index["weight_map"].values()):
        assert (model_path / filename).is_file(), f"缺少模型权重：{filename}"

    questions = [
        "请只输出计算结果：1+1等于多少？",
        "小明有3袋糖果，每袋5颗，一共有多少颗？请只输出最终数字。",
    ]
    tokenizer = AutoTokenizer.from_pretrained(
        str(model_path), local_files_only=True
    )
    prompts = [
        tokenizer.apply_chat_template(
            [{"role": "user", "content": question}],
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        for question in questions
    ]
    engine_kwargs = dict(
        model=str(model_path),
        dtype="bfloat16",
        tensor_parallel_size=1,
        distributed_executor_backend="mp",
        max_model_len=1024,
        max_num_batched_tokens=1024,
        max_num_seqs=2,
        gpu_memory_utilization=0.25,
        enforce_eager=True,
        enable_chunked_prefill=False,
        enable_prefix_caching=False,
        language_model_only=True,
        generation_config="vllm",
        seed=42,
    )
    print("当前平台：", type(current_platform).__name__, flush=True)
    print("推理配置：", json.dumps(engine_kwargs, ensure_ascii=False), flush=True)
    print("开始初始化单卡推理引擎……", flush=True)
    start = time.perf_counter()
    llm = LLM(**engine_kwargs)
    init_seconds = time.perf_counter() - start
    print(f"推理引擎初始化完成，耗时{init_seconds:.1f}秒", flush=True)

    try:
        sampling_params = SamplingParams(temperature=0.0, max_tokens=128)
        start = time.perf_counter()
        outputs = llm.generate(
            prompts, sampling_params=sampling_params, use_tqdm=False
        )
        generate_seconds = time.perf_counter() - start
        assert len(outputs) == len(questions), "生成结果数量不符"
        rows = []
        for question, output in zip(questions, outputs):
            assert len(output.outputs) == 1, "每个问题应返回一个候选回答"
            candidate = output.outputs[0]
            row = dict(
                question=question,
                answer=candidate.text,
                output_tokens=len(candidate.token_ids),
                finish_reason=candidate.finish_reason,
            )
            rows.append(row)
            print("问题：", question, flush=True)
            print("回答：", repr(candidate.text), flush=True)
            print(
                "输出token数：", row["output_tokens"],
                "结束原因：", row["finish_reason"], flush=True,
            )

        result = dict(
            check="generation_smoke_check_not_accuracy_benchmark",
            versions=versions,
            engine_kwargs=engine_kwargs,
            sampling=dict(temperature=0.0, max_tokens=128),
            enable_thinking=False,
            init_seconds=init_seconds,
            generate_seconds=generate_seconds,
            samples=rows,
        )
        result_path.parent.mkdir(parents=True, exist_ok=True)
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2))
        assert all(r["answer"].strip() and r["output_tokens"] > 0 for r in rows), (
            "存在空回答，请检查结果文件和日志"
        )
        print("结果已保存：", result_path, flush=True)
        print(f"本次生成耗时：{generate_seconds:.2f}秒", flush=True)
    finally:
        print("关闭本次测试的推理引擎……", flush=True)
        llm.llm_engine.engine_core.shutdown(timeout=60)

    print("Qwen3.5-0.8B单卡vLLM NPU生成检查通过", flush=True)


if __name__ == "__main__":
    main()
