"""Offline, resumable GSM8K evaluation; launch manually inside verl91.

Eight independent TP=1 engines evaluate fixed disjoint portions of the test set.
--prepare-only checks inputs/configuration without constructing an inference engine.
Use the same script and protocol with --model and a new --label after training.
"""

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


W = Path('/data1/f00951948_cann91')
TOKENIZER_PATH = W / 'models/Qwen3.5-0.8B'
WORKERS = 8
BATCH_SIZE = 4
ENGINE = {
    'dtype': 'bfloat16', 'tensor_parallel_size': 1,
    'distributed_executor_backend': 'mp',
    'max_model_len': 2048, 'max_num_batched_tokens': 4096, 'max_num_seqs': BATCH_SIZE,
    'gpu_memory_utilization': 0.25, 'enforce_eager': True,
    'enable_chunked_prefill': False, 'enable_prefix_caching': False,
    'language_model_only': True, 'generation_config': 'vllm', 'seed': 42,
}
SAMPLING = {
    'n': 1, 'temperature': 0.0, 'top_p': 1.0, 'top_k': -1,
    'max_tokens': 1024, 'seed': 42, 'skip_special_tokens': True,
}


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def json_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(path)


def guard():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    for key in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'HF_HUB_DISABLE_TELEMETRY'):
        os.environ[key] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    os.environ['VLLM_NO_USAGE_STATS'] = '1'
    os.environ['DO_NOT_TRACK'] = '1'


def batches(worker_index, total):
    indices = list(range(worker_index, total, WORKERS))
    return [indices[i:i + BATCH_SIZE] for i in range(0, len(indices), BATCH_SIZE)]


def batch_file(run_dir, worker_index, batch_index):
    return run_dir / f'worker_{worker_index}' / f'batch_{batch_index:04d}.json'


def read_batch(path, cfg, expected_indices):
    value = json.loads(path.read_text())
    assert value['run_fingerprint'] == cfg['run_fingerprint'], f'批次配置不一致：{path}'
    assert value['indices'] == expected_indices, f'批次题目不一致：{path}'
    assert [row['index'] for row in value['rows']] == expected_indices
    return value['rows']


def prepare(model_path, label):
    import pyarrow.parquet as pq
    from transformers import AutoTokenizer
    from vllm import SamplingParams
    from vllm.engine.arg_utils import EngineArgs
    import verl.utils.reward_score.gsm8k as scorer

    assert re.fullmatch(r'[A-Za-z0-9_-]{1,64}', label), 'label只能使用字母、数字、下划线和连字符'
    assert model_path.is_dir() and (model_path / 'config.json').is_file(), '缺少HF格式模型目录或config.json'
    expected = json.loads((W / 'records/24_verl_install_check.json').read_text())['protected_versions']
    for name, version in expected.items():
        assert metadata.version(name) == version, f'{name}版本已改变'
    data_check = json.loads((W / 'records/28_gsm8k_data_check.json').read_text())
    assert data_check['passed']
    test_path = Path(data_check['files']['test']['path'])
    assert sha_file(test_path) == data_check['files']['test']['sha256']
    raw = pq.read_table(test_path).to_pylist()
    assert len(raw) == 1319
    tokenizer = AutoTokenizer.from_pretrained(str(TOKENIZER_PATH), local_files_only=True)
    inputs = []
    for index, row in enumerate(raw):
        ids = tokenizer.apply_chat_template(
            row['prompt'], tokenize=True, return_dict=False,
            add_generation_prompt=True, enable_thinking=False,
        )
        assert len(ids) <= data_check['max_prompt_length']
        assert len(ids) + SAMPLING['max_tokens'] <= ENGINE['max_model_len']
        inputs.append({
            'index': index, 'sample_id': row['extra_info']['sample_id'],
            'question': row['extra_info']['question'],
            'prompt_token_ids': ids,
            'ground_truth': row['reward_model']['ground_truth'],
        })
    assert len({r['sample_id'] for r in inputs}) == len(inputs)
    weights = sorted(model_path.glob('*.safetensors'))
    assert weights, '未找到HF格式safetensors模型权重'
    print('核验模型权重身份和评测输入……', flush=True)
    model_files = [model_path / 'config.json', *weights]
    if (model_path / 'model.safetensors.index.json').is_file():
        model_files.append(model_path / 'model.safetensors.index.json')
    model_identity = {p.name: {'sha256': sha_file(p), 'bytes': p.stat().st_size} for p in model_files}
    tokenizer_identity = {
        name: sha_file(TOKENIZER_PATH / name)
        for name in ('tokenizer.json', 'tokenizer_config.json', 'vocab.json', 'merges.txt',
                     'special_tokens_map.json', 'chat_template.jinja')
        if (TOKENIZER_PATH / name).is_file()
    }
    versions = {n: metadata.version(n) for n in (
        'torch', 'torch_npu', 'numpy', 'transformers', 'vllm', 'vllm-ascend', 'triton-ascend', 'verl'
    )}
    protocol = {
        'schema_version': 1, 'test_parquet_sha256': sha_file(test_path),
        'input_fingerprint': json_hash(inputs), 'total_questions': len(inputs),
        'tokenizer_path': str(TOKENIZER_PATH), 'tokenizer_files': tokenizer_identity,
        'enable_thinking': False, 'engine': ENGINE, 'sampling': SAMPLING,
        'data_parallel_workers': WORKERS, 'fixed_worker_batch_size': BATCH_SIZE,
        'scorer': 'verl.utils.reward_score.gsm8k.compute_score',
        'scorer_sha256': sha_file(Path(scorer.__file__)), 'score_method': 'strict',
        'failed_or_empty_answers': 'counted in the fixed denominator and receive zero',
        'versions': versions,
    }
    # Construct argument objects only. No engine, model or NPU computation here.
    EngineArgs(model=str(model_path), tokenizer=str(TOKENIZER_PATH), **ENGINE)
    SamplingParams(**SAMPLING)
    identity = {'model_path': str(model_path), 'model_files': model_identity,
                'label': label, 'protocol': protocol}
    cfg = {**identity, 'protocol_fingerprint': json_hash(protocol),
           'run_fingerprint': json_hash(identity)}
    run_dir = W / 'eval/gsm8k' / label
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / 'run_config.json'
    if path.exists():
        assert json.loads(path.read_text()) == cfg, '同名评测目录的配置或模型已改变，请使用新的label'
        assert json.loads((run_dir / 'inputs.json').read_text()) == inputs, '已保存的评测输入不一致'
    else:
        atomic_json(run_dir / 'inputs.json', inputs)
        atomic_json(path, cfg)
    # Verify coverage and any already completed atomic batches before resuming.
    all_indices, pending = [], []
    for worker_index in range(WORKERS):
        needs_work = False
        for batch_index, indices in enumerate(batches(worker_index, len(inputs))):
            all_indices.extend(indices)
            p = batch_file(run_dir, worker_index, batch_index)
            if p.exists():
                read_batch(p, cfg, indices)
            else:
                needs_work = True
        if needs_work:
            pending.append(worker_index)
    assert sorted(all_indices) == list(range(len(inputs)))
    print(f'评测配置预检通过：{len(inputs)}题，8卡各处理不同题目，每题生成1个回答', flush=True)
    print(f'温度=0，thinking关闭，最多生成1024 tokens；最长输入={max(len(r["prompt_token_ids"]) for r in inputs)} tokens', flush=True)
    print('评测目录：', run_dir, flush=True)
    return cfg, inputs, run_dir, pending


def worker(run_dir, worker_index):
    assert 0 <= worker_index < WORKERS
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == str(worker_index)
    cfg = json.loads((run_dir / 'run_config.json').read_text())
    inputs = json.loads((run_dir / 'inputs.json').read_text())
    assert json_hash(inputs) == cfg['protocol']['input_fingerprint']
    from vllm import LLM, SamplingParams
    from vllm.platforms import current_platform
    import torch
    from verl.utils.reward_score.gsm8k import compute_score, extract_solution

    assert current_platform.device_type == 'npu'
    assert torch.npu.device_count() == 1, '每个评测Worker应只看到分配给它的一张卡'
    torch.set_num_threads(4)
    worker_dir = run_dir / f'worker_{worker_index}'
    worker_dir.mkdir(exist_ok=True)
    progress_path = worker_dir / 'progress.json'
    work = batches(worker_index, len(inputs))
    processed = sum(len(ids) for i, ids in enumerate(work) if batch_file(run_dir, worker_index, i).exists())

    def progress(status):
        atomic_json(progress_path, {'worker': worker_index, 'status': status,
                                  'processed': processed, 'total': sum(map(len, work))})

    progress('initializing')
    llm = None
    try:
        llm = LLM(model=cfg['model_path'], tokenizer=cfg['protocol']['tokenizer_path'],
                  **cfg['protocol']['engine'])
        params = SamplingParams(**cfg['protocol']['sampling'])
        for batch_index, indices in enumerate(work):
            path = batch_file(run_dir, worker_index, batch_index)
            if path.exists():
                read_batch(path, cfg, indices)
                continue
            progress('generating')
            token_prompts = [{'prompt_token_ids': inputs[i]['prompt_token_ids']} for i in indices]
            outputs = llm.generate(token_prompts, sampling_params=params, use_tqdm=False)
            assert len(outputs) == len(indices), '推理返回的题目数量不一致'
            results = []
            for index, output in zip(indices, outputs):
                item = inputs[index]
                assert output.prompt_token_ids == item['prompt_token_ids'], '推理输出与输入顺序不一致'
                assert len(output.outputs) <= 1, '每题应只返回一个回答'
                candidate = output.outputs[0] if output.outputs else None
                text = candidate.text if candidate is not None else ''
                reason = candidate.finish_reason if candidate is not None else None
                error = None if reason in ('stop', 'length') else f'unexpected_finish_reason:{reason}'
                predicted = extract_solution(text, method='strict')
                usable = error is None and bool(text.strip())
                score = float(compute_score(text, item['ground_truth'], method='strict')) if usable else 0.0
                results.append({
                    'index': index, 'sample_id': item['sample_id'], 'question': item['question'],
                    'ground_truth': item['ground_truth'], 'generated_text': text,
                    'extracted_answer': predicted, 'score': score,
                    'format_ok': usable and predicted is not None,
                    'empty_answer': not bool(text.strip()), 'generation_error': error,
                    'prompt_tokens': len(item['prompt_token_ids']),
                    'output_tokens': len(candidate.token_ids) if candidate is not None else 0,
                    'finish_reason': reason, 'truncated': reason == 'length',
                })
            atomic_json(path, {'run_fingerprint': cfg['run_fingerprint'],
                              'indices': indices, 'rows': results})
            processed += len(indices)
            progress('generating')
            print(f'NPU {worker_index}：{processed}/{sum(map(len, work))}', flush=True)
    except BaseException:
        progress('failed')
        raise
    finally:
        if llm is not None:
            llm.llm_engine.engine_core.shutdown(timeout=60)
    progress('done')


def launch(cfg, inputs, run_dir, pending):
    if not pending:
        return
    p = subprocess.run(['npu-smi', 'info'], text=True, capture_output=True, timeout=30)
    info = p.stdout + p.stderr
    (run_dir / 'npu_before.log').write_text(info)
    assert p.returncode == 0, 'npu-smi检查失败，请查看npu_before.log'
    idle = {int(x) for x in re.findall(r'No running processes found in NPU\s+(\d+)', info)}
    assert set(pending) <= idle, f'这些待用卡未确认空闲：{sorted(set(pending) - idle)}；请查看npu_before.log'
    processes, log_files = [], []
    old_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGHUP)}

    def terminate(signum, frame):
        raise KeyboardInterrupt('收到停止信号')

    for sig in old_handlers:
        signal.signal(sig, terminate)
    try:
        for index in pending:
            env = os.environ.copy()
            env['ASCEND_RT_VISIBLE_DEVICES'] = str(index)
            env['VLLM_WORKER_MULTIPROC_METHOD'] = 'spawn'
            env['VLLM_HOST_IP'] = '127.0.0.1'
            for key in ('RANK', 'LOCAL_RANK', 'WORLD_SIZE', 'LOCAL_WORLD_SIZE', 'MASTER_ADDR', 'MASTER_PORT'):
                env.pop(key, None)
            for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
                env[key] = '4'
            log = (run_dir / f'worker_{index}.log').open('a')
            log_files.append(log)
            proc = subprocess.Popen(
                [sys.executable, '-u', str(Path(__file__).resolve()), '--worker-index', str(index),
                 '--run-dir', str(run_dir)], env=env, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            processes.append((index, proc))
            print(f'已启动NPU {index}评测Worker，PID={proc.pid}，日志=worker_{index}.log', flush=True)
        last_report = 0.0
        while True:
            for index, proc in processes:
                code = proc.poll()
                if code is not None and code != 0:
                    path = run_dir / f'worker_{index}.log'
                    print(f'Worker {index}失败，退出码={code}，日志={path}', flush=True)
                    print('\n'.join(path.read_text(errors='replace').splitlines()[-25:]), flush=True)
                    raise RuntimeError('评测未完成；已完成的批次保留，修复后可用相同命令续跑')
            if time.monotonic() - last_report >= 15:
                done, initializing, generating = 0, 0, 0
                for index in range(WORKERS):
                    state_file = run_dir / f'worker_{index}/progress.json'
                    if state_file.exists():
                        state = json.loads(state_file.read_text())
                        done += state['processed']
                        initializing += state['status'] == 'initializing'
                        generating += state['status'] == 'generating'
                print(f'评测进度：{done}/{len(inputs)}；初始化Worker={initializing}，生成中Worker={generating}', flush=True)
                last_report = time.monotonic()
            if all(proc.poll() is not None for _, proc in processes):
                break
            time.sleep(2)
    finally:
        # Each started worker owns its process group; never stop unrelated jobs.
        for _, proc in processes:
            if proc.poll() is None:
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + 20
        for _, proc in processes:
            try:
                proc.wait(timeout=max(0.1, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=10)
        for log in log_files:
            log.close()
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)


def summarize(cfg, inputs, run_dir, elapsed):
    from verl.utils.reward_score.gsm8k import compute_score

    results = []
    for worker_index in range(WORKERS):
        for batch_index, indices in enumerate(batches(worker_index, len(inputs))):
            results.extend(read_batch(batch_file(run_dir, worker_index, batch_index), cfg, indices))
    results.sort(key=lambda x: x['index'])
    assert [r['index'] for r in results] == list(range(1319)), '未收齐全部测试题，停止汇总最终准确率'
    for row, item in zip(results, inputs):
        assert row['sample_id'] == item['sample_id'] and row['ground_truth'] == item['ground_truth']
        score = float(compute_score(row['generated_text'], item['ground_truth'], method='strict'))
        if row['generation_error'] is not None or row['empty_answer']:
            score = 0.0
        assert score == row['score'], '分数复核不一致'
    total = len(results)
    correct = sum(r['score'] == 1.0 for r in results)
    format_count = sum(r['format_ok'] for r in results)
    truncated = sum(r['truncated'] for r in results)
    metrics = {
        'label': cfg['label'], 'model_path': cfg['model_path'],
        'time_utc': datetime.now(timezone.utc).isoformat(),
        'total_count': total, 'correct_count': correct,
        'accuracy': correct / total, 'accuracy_percent': 100 * correct / total,
        'format_compliant_count': format_count, 'format_compliance_rate': format_count / total,
        'truncated_count': truncated, 'truncation_rate': truncated / total,
        'empty_answer_count': sum(r['empty_answer'] for r in results),
        'generation_error_count': sum(r['generation_error'] is not None for r in results),
        'mean_output_tokens': sum(r['output_tokens'] for r in results) / total,
        'protocol_fingerprint': cfg['protocol_fingerprint'],
        'run_fingerprint': cfg['run_fingerprint'],
        'elapsed_seconds_this_invocation': round(elapsed, 2),
        'complete': True,
    }
    tmp = run_dir / 'predictions.jsonl.tmp'
    with tmp.open('w') as f:
        for row in results:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')
    tmp.replace(run_dir / 'predictions.jsonl')
    atomic_json(run_dir / 'metrics.json', metrics)
    print(f'完整测试题数：{total}；正确题数：{correct}', flush=True)
    print(f'严格准确率：{100 * correct / total:.2f}% ({correct}/{total})', flush=True)
    print(f'格式符合率：{100 * format_count / total:.2f}%', flush=True)
    print(f'回答截断比例：{100 * truncated / total:.2f}%', flush=True)
    print(f'空回答数：{metrics["empty_answer_count"]}；生成异常数：{metrics["generation_error_count"]}', flush=True)
    print('指标文件：', run_dir / 'metrics.json', flush=True)
    print('逐题结果：', run_dir / 'predictions.jsonl', flush=True)
    print(f'GSM8K评测完成：{cfg["label"]}', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default=str(TOKENIZER_PATH))
    parser.add_argument('--label', default='baseline')
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--worker-index', type=int)
    parser.add_argument('--run-dir')
    args = parser.parse_args()
    guard()
    if args.worker_index is not None:
        run_dir = Path(args.run_dir).resolve()
        assert run_dir.is_relative_to(W / 'eval/gsm8k')
        worker(run_dir, args.worker_index)
        return
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '0,1,2,3,4,5,6,7'
    started = time.monotonic()
    root = W / 'eval/gsm8k'
    root.mkdir(parents=True, exist_ok=True)
    with (root / '.evaluation.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('当前已有本工作区的GSM8K评测在运行，请查看其进度和日志') from exc
        cfg, inputs, run_dir, pending = prepare(Path(args.model).resolve(), args.label)
        if args.prepare_only:
            print('仅完成CPU输入与配置准备；推理引擎尚未启动', flush=True)
            return
        launch(cfg, inputs, run_dir, pending)
        summarize(cfg, inputs, run_dir, time.monotonic() - started)


if __name__ == '__main__':
    main()
