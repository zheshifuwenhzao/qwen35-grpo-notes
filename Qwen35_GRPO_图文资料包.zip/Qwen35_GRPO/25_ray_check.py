"""User-run Ray scheduling check; actors inspect assignments without NPU compute."""

import importlib.metadata as metadata
import json
import os
from pathlib import Path
import signal
import sys
import time


W = Path('/data1/f00951948_cann91')


def main():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '0,1,2,3,4,5,6,7'
    assert not os.environ.get('RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES'), (
        '检测到禁用 Ray 设置 NPU 可见性的变量，请先核对该变量'
    )
    os.environ['RAY_USAGE_STATS_ENABLED'] = '0'
    os.environ['RAY_ENABLE_UV_RUN_RUNTIME_ENV'] = '0'
    import ray

    def deadline(signum, frame):
        raise TimeoutError('Ray 调度检查超过 240 秒，请查看本步日志')

    signal.signal(signal.SIGALRM, deadline)
    signal.alarm(240)
    actors = []
    result = None
    started = time.monotonic()
    try:
        print('启动本次检查专用的本地 Ray 实例……', flush=True)
        ray.init(
            address='local',
            namespace='f00951948_verl91_check',
            num_cpus=16,
            num_gpus=0,
            resources={'NPU': 8},
            include_dashboard=False,
            object_store_memory=256 * 1024 * 1024,
            _node_ip_address='127.0.0.1',
            _temp_dir=str(W / 'tmp/r25'),
        )
        resources = ray.cluster_resources()
        print('Ray 资源：', resources, flush=True)
        assert resources.get('NPU') == 8, resources
        assert resources.get('CPU') == 16, resources
        assert len([n for n in ray.nodes() if n['Alive']]) == 1

        @ray.remote(num_cpus=1, resources={'NPU': 1}, max_restarts=0)
        class WorkerProbe:
            def report(self, index):
                import importlib.metadata
                import os
                import sys
                import ray

                return {
                    'worker': index,
                    'pid': os.getpid(),
                    'python': sys.executable,
                    'prefix': sys.prefix,
                    'verl': importlib.metadata.version('verl'),
                    'accelerator_ids': ray.get_runtime_context().get_accelerator_ids(),
                    'visible_npu': os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),
                    'cpu_result': index * index,
                }

        print('创建 8 个各申请一张 NPU 的 Worker……', flush=True)
        actors = [WorkerProbe.remote() for _ in range(8)]
        reports = ray.get([a.report.remote(i) for i, a in enumerate(actors)], timeout=120)
        assigned = []
        for report in reports:
            ids = report['accelerator_ids'].get('NPU', [])
            assert len(ids) == 1, report
            assert report['visible_npu'] == str(ids[0]), report
            assert report['prefix'] == str(W / 'envs/verl91'), report
            assert report['verl'] == '0.9.1', report
            assert report['cpu_result'] == report['worker'] ** 2, report
            assigned.append(int(ids[0]))
            print(
                f"Worker {report['worker']}：PID={report['pid']}，"
                f"分配NPU={ids[0]}，可见NPU={report['visible_npu']}，VERL={report['verl']}",
                flush=True,
            )
        assert sorted(assigned) == list(range(8)), assigned
        assert len({r['pid'] for r in reports}) == 8
        result = {
            'ray': metadata.version('ray'),
            'cluster_resources': resources,
            'workers': reports,
            'seconds': round(time.monotonic() - started, 2),
            'scope': 'Logical NPU scheduling and worker Python environments; no NPU model compute.',
            'passed': True,
        }
    finally:
        signal.alarm(0)
        if ray.is_initialized():
            for actor in actors:
                ray.kill(actor, no_restart=True)
        ray.shutdown()
        print('本次 Ray 检查实例已关闭', flush=True)
    assert result is not None
    (W / 'records/25_ray_check.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    )
    print('Ray八Worker调度及NPU分配检查通过', flush=True)


if __name__ == '__main__':
    main()
