"""User-run official FSDP export plus tensor-level integrity/update checks.

Model reloading for inference is exercised by the subsequent step-29 evaluator.
--prepare-only reads source files and metadata without merging/model execution.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


W = Path('/data1/f00951948_cann91')
ORIGINAL = W / 'models/Qwen3.5-0.8B'
CHECKPOINT = W / 'runs/qwen35_grpo10/checkpoints/global_step_10/actor'
OUTPUT = W / 'models/Qwen3.5-0.8B-grpo-step10'
TRACKED = 'model.language_model.layers.0.linear_attn.out_proj.weight'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)


def guard():
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python环境不是verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活verl91'
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'


def prepare():
    from verl.model_merger.base_model_merger import ModelMergerConfig
    from verl.model_merger.fsdp_model_merger import FSDPModelMerger

    trained = json.loads((W / 'runs/qwen35_grpo10/training_complete.json').read_text())
    assert trained['passed'] and trained['completed_steps'] == 10
    assert json.loads((CHECKPOINT / 'fsdp_config.json').read_text())['world_size'] == 8
    print('核验八个模型分片及原始权重的校验值……', flush=True)
    shards = {}
    for rank in range(8):
        p = CHECKPOINT / f'model_world_size_8_rank_{rank}.pt'
        assert p.is_file() and p.stat().st_size > 0
        shards[p.name] = {'sha256': digest(p), 'bytes': p.stat().st_size}
    baseline = json.loads((W / 'eval/gsm8k/baseline/run_config.json').read_text())
    for name, spec in baseline['model_files'].items():
        assert digest(ORIGINAL / name) == spec['sha256'], f'原始模型文件变化：{name}'
    cfg = ModelMergerConfig(
        operation='merge', backend='fsdp', local_dir=str(CHECKPOINT),
        hf_model_config_path=str(ORIGINAL),
        target_dir=str(OUTPUT), use_cpu_initialization=True,
    )
    merger = FSDPModelMerger(cfg)
    assert merger._get_world_size() == 8
    assert merger.model_config.architectures == ['Qwen3_5ForConditionalGeneration']
    assert merger.get_transformers_auto_model_class() is not None
    source = {'checkpoint': str(CHECKPOINT), 'shards': shards,
              'fsdp_config_sha256': digest(CHECKPOINT / 'fsdp_config.json'),
              'export_configuration_source': str(ORIGINAL),
              'original_config_sha256': digest(ORIGINAL / 'config.json')}
    source_hash = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()
    print('官方FSDP合并接口及检查点元数据预检通过', flush=True)
    return source, source_hash


def read_tensor(folder, key):
    from safetensors import safe_open

    index = folder / 'model.safetensors.index.json'
    if index.exists():
        mapping = json.loads(index.read_text())['weight_map']
        assert key in mapping, f'权重索引缺少目标参数：{key}'
        files = [folder / mapping[key]]
    else:
        files = sorted(folder.glob('*.safetensors'))
    for p in files:
        with safe_open(str(p), framework='pt', device='cpu') as f:
            if key in f.keys():
                return f.get_tensor(key)
    raise RuntimeError(f'{folder}中未找到目标参数{key}')


def verify_export(folder):
    import torch
    import pyarrow.parquet as pq
    from transformers import AutoConfig, AutoTokenizer
    from verl.model_merger.output_validation import validate_hf_model_output

    torch.set_num_threads(4)
    validate_hf_model_output(folder)
    cfg = AutoConfig.from_pretrained(str(folder), local_files_only=True)
    original_cfg = AutoConfig.from_pretrained(str(ORIGINAL), local_files_only=True)
    assert cfg.architectures == ['Qwen3_5ForConditionalGeneration']
    for scope in ('root', 'text_config'):
        current = cfg if scope == 'root' else cfg.text_config
        reference = original_cfg if scope == 'root' else original_cfg.text_config
        for key in ('model_type', 'tie_word_embeddings', 'bos_token_id', 'eos_token_id', 'pad_token_id',
                    'vocab_size', 'hidden_size', 'num_hidden_layers'):
            assert getattr(current, key, None) == getattr(reference, key, None), f'{scope}.{key}与原始配置不一致'
    old = read_tensor(ORIGINAL, TRACKED)
    new = read_tensor(folder, TRACKED)
    assert old.shape == new.shape
    assert torch.isfinite(new).all(), '导出参数包含NaN/Inf'
    delta = new.float() - old.float()
    changed = int(torch.count_nonzero(delta).item())
    norm = float(torch.linalg.vector_norm(delta).item())
    assert changed > 0 and norm > 0, '目标参数在BF16导出后未观察到变化，需要进一步检查'
    tokenizer = AutoTokenizer.from_pretrained(str(folder), local_files_only=True)
    question = pq.read_table(W / 'data/gsm8k/test.parquet').to_pylist()[0]['prompt']
    ids = tokenizer.apply_chat_template(
        question, tokenize=True, return_dict=False, add_generation_prompt=True, enable_thinking=False,
    )
    baseline_ids = json.loads((W / 'eval/gsm8k/baseline/inputs.json').read_text())[0]['prompt_token_ids']
    assert ids == baseline_ids, '导出Tokenizer与基线提示词不一致'
    files = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size}
             for p in sorted(folder.iterdir()) if p.is_file() and p.name != 'f00951948_export_manifest.json'}
    print(f'导出权重检查通过：参数形状={tuple(new.shape)}，变化元素={changed}，变化L2={norm:.8g}', flush=True)
    print('导出Tokenizer与基线提示词一致', flush=True)
    return {'tracked_parameter': TRACKED, 'changed_elements': changed,
            'architecture_and_special_tokens_match_original': True,
            'update_l2': norm, 'files': files, 'tokenizer_check_passed': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    guard()
    source, source_hash = prepare()
    if args.prepare_only:
        write_json(W / 'records/31_export_preflight.json', {
            'passed': True, 'source': source, 'source_fingerprint': source_hash,
            'target': str(OUTPUT), 'merge_executed': False,
        })
        print('仅核验来源和接口，尚未合并检查点', flush=True)
        return
    if OUTPUT.exists():
        marker = OUTPUT / 'f00951948_export_manifest.json'
        assert marker.is_file(), '目标目录已有内容且缺少本次导出记录，停止覆盖'
        saved = json.loads(marker.read_text())
        assert saved['source_fingerprint'] == source_hash, '已有导出模型的检查点来源不同'
        for name, spec in saved['verification']['files'].items():
            assert digest(OUTPUT / name) == spec['sha256'], f'已有导出文件已变化：{name}'
        verification = verify_export(OUTPUT)
    else:
        stage = OUTPUT.with_name(OUTPUT.name + '.exporting')
        plan = {'source_fingerprint': source_hash, 'target': str(OUTPUT)}
        if stage.exists():
            assert (stage / 'export_plan.json').is_file(), '暂存目录来源不明，停止覆盖'
            assert json.loads((stage / 'export_plan.json').read_text()) == plan
        else:
            stage.mkdir()
            write_json(stage / 'export_plan.json', plan)
        from verl.model_merger.base_model_merger import ModelMergerConfig
        from verl.model_merger.fsdp_model_merger import FSDPModelMerger

        # Training HFModelConfig injects root EOS/PAD defaults. Keep the original
        # architecture/generation/tokenizer config so evaluation changes weights
        # without introducing a different stopping configuration.
        merger = FSDPModelMerger(ModelMergerConfig(
            operation='merge', backend='fsdp', local_dir=str(CHECKPOINT),
            hf_model_config_path=str(ORIGINAL), target_dir=str(stage),
            use_cpu_initialization=True,
        ))
        print('调用官方FSDPModelMerger：配置沿用原始模型，权重来自第10步检查点', flush=True)
        merger.merge_and_save()
        merger.cleanup()
        verification = verify_export(stage)
        write_json(stage / 'f00951948_export_manifest.json', {
            'source': source, 'source_fingerprint': source_hash, 'verification': verification,
        })
        stage.rename(OUTPUT)
    write_json(W / 'records/31_grpo_export_check.json', {
        'passed': True, 'checkpoint': str(CHECKPOINT), 'model_path': str(OUTPUT),
        'source_fingerprint': source_hash, 'verification': verification,
        'inference_reload_tested': False,
    })
    print('GRPO检查点合并及权重变化检查通过', flush=True)
    print('导出模型：', OUTPUT, flush=True)


if __name__ == '__main__':
    main()
