"""User-run, locally logged Qwen3.5 GSM8K GRPO profile on eight Ascend NPUs.

--prepare-only performs configuration/data/module checks without starting Ray,
loading model weights into a model, or launching training.
"""

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time


W = Path('/data1/f00951948_cann91')
MODEL = W / 'models/Qwen3.5-0.8B'


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)


def setup_env(run_dir):
    assert Path('/.dockerenv').is_file(), '当前不在容器内'
    assert Path(sys.prefix) == W / 'envs/verl91', 'Python 环境不是 verl91'
    assert os.environ.get('CONDA_PREFIX') == str(W / 'envs/verl91'), '未激活 verl91'
    assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES') == '0,1,2,3,4,5,6,7'
    python_path = os.pathsep.join(dict.fromkeys(
        [str(W / 'scripts')] + [p for p in os.environ.get('PYTHONPATH', '').split(os.pathsep) if p]
    ))
    env = {
        'PYTHONPATH': python_path,
        'HF_HUB_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
        'HF_HUB_DISABLE_TELEMETRY': '1', 'TOKENIZERS_PARALLELISM': 'false',
        'WANDB_MODE': 'disabled', 'VLLM_NO_USAGE_STATS': '1', 'DO_NOT_TRACK': '1',
        'RAY_USAGE_STATS_ENABLED': '0', 'RAY_ENABLE_UV_RUN_RUNTIME_ENV': '0',
        'RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES': '1',
        'ASCEND_RT_VISIBLE_DEVICES': '0,1,2,3,4,5,6,7',
        'VLLM_WORKER_MULTIPROC_METHOD': 'spawn', 'VLLM_HOST_IP': '127.0.0.1',
        'VLLM_ASCEND_ENABLE_NZ': '0',
        'PYTORCH_NPU_ALLOC_CONF': 'expandable_segments:False',
        'HCCL_CONNECT_TIMEOUT': '600', 'HCCL_EXEC_TIMEOUT': '600',
        'HCCL_HOST_SOCKET_PORT_RANGE': 'auto', 'HCCL_NPU_SOCKET_PORT_RANGE': 'auto',
        'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4', 'OPENBLAS_NUM_THREADS': '4',
        'TENSORBOARD_DIR': str(run_dir / 'tensorboard'),
        'VERL_FILE_LOGGER_PATH': str(run_dir / 'metrics.jsonl'),
        'CONDA_PREFIX': str(W / 'envs/verl91'),
    }
    os.environ.update(env)
    return env


def prepare(run_dir, steps, env):
    from hydra import compose, initialize_config_dir
    from omegaconf import OmegaConf
    import pyarrow.parquet as pq
    import verl
    from verl.checkpoint_engine import CheckpointEngineRegistry
    from verl.trainer.ppo.utils import need_critic, need_reference_policy
    from verl.trainer.ppo.v1 import get_trainer_cls
    from verl.utils.config import omega_conf_to_dataclass, validate_config
    from verl.utils.dataset.rl_dataset import RLHFDataset
    from verl.utils.device import is_support_ipc

    expected = json.loads((W / 'records/24_verl_install_check.json').read_text())['protected_versions']
    for name, version in expected.items():
        assert metadata.version(name) == version, f'{name}版本与已验证环境不同'
    data = json.loads((W / 'records/28_gsm8k_data_check.json').read_text())
    baseline_dir = W / 'eval/gsm8k/baseline'
    baseline = json.loads((baseline_dir / 'metrics.json').read_text())
    baseline_config = json.loads((baseline_dir / 'run_config.json').read_text())
    assert baseline['complete'] and baseline['total_count'] == 1319
    assert Path(baseline['model_path']) == MODEL
    for name, spec in baseline_config['model_files'].items():
        assert sha_file(MODEL / name) == spec['sha256'], f'原始模型文件变化：{name}'
    for split, spec in data['files'].items():
        assert sha_file(Path(spec['path'])) == spec['sha256'], f'{split}数据文件变化'
    assert data['prompt_token_stats']['train']['max'] <= 256
    assert data['prompt_token_stats']['val']['max'] <= 256

    with initialize_config_dir(version_base=None, config_dir=str(Path(verl.__file__).parent / 'trainer/config')):
        cfg = compose(config_name='ppo_trainer')
    overrides = {
        'algorithm.adv_estimator': 'grpo',
        'algorithm.use_kl_in_reward': False,
        'data.train_files': [data['files']['train']['path']],
        'data.val_files': [data['files']['val']['path']],
        'data.train_batch_size': 16, 'data.val_batch_size': 32,
        'data.max_prompt_length': 256, 'data.max_response_length': 1024,
        'data.apply_chat_template_kwargs': {'enable_thinking': False},
        'data.dataloader_num_workers': 0, 'data.filter_overlong_prompts_workers': 1,
        'data.seed': 42, 'data.shuffle': True, 'data.validation_shuffle': False,
        'actor_rollout_ref.model.path': str(MODEL),
        'actor_rollout_ref.model.external_lib': 'f00951948_npu_runtime',
        'actor_rollout_ref.model.override_config': {'attn_implementation': 'eager', 'use_cache': False},
        'actor_rollout_ref.model.use_remove_padding': False,
        'actor_rollout_ref.model.enable_gradient_checkpointing': False,
        'actor_rollout_ref.model.use_fused_kernels': False,
        'actor_rollout_ref.actor.strategy': 'fsdp2',
        'actor_rollout_ref.actor.fsdp_config.strategy': 'fsdp2',
        'actor_rollout_ref.actor.fsdp_config.model_dtype': 'fp32',
        'actor_rollout_ref.actor.fsdp_config.use_torch_compile': False,
        'actor_rollout_ref.actor.fsdp_config.param_offload': False,
        'actor_rollout_ref.actor.fsdp_config.optimizer_offload': False,
        'actor_rollout_ref.actor.fsdp_config.offload_policy': False,
        'actor_rollout_ref.actor.use_torch_compile': False,
        'actor_rollout_ref.actor.use_dynamic_bsz': False,
        'actor_rollout_ref.actor.ppo_mini_batch_size': 16,
        'actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu': 1,
        'actor_rollout_ref.actor.ppo_epochs': 1,
        'actor_rollout_ref.actor.use_kl_loss': True,
        'actor_rollout_ref.actor.kl_loss_coef': 0.001,
        'actor_rollout_ref.actor.optim.lr': 1e-6,
        'actor_rollout_ref.actor.optim.weight_decay': 0.0,
        'actor_rollout_ref.actor.optim.override_optimizer_config': {'foreach': False, 'fused': False},
        'actor_rollout_ref.ref.strategy': 'fsdp2',
        'actor_rollout_ref.ref.fsdp_config.strategy': 'fsdp2',
        'actor_rollout_ref.ref.fsdp_config.model_dtype': 'bf16',
        'actor_rollout_ref.ref.fsdp_config.use_torch_compile': False,
        'actor_rollout_ref.ref.use_torch_compile': False,
        'actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu': 1,
        'actor_rollout_ref.rollout.name': 'vllm',
        'actor_rollout_ref.rollout.mode': 'async',
        'actor_rollout_ref.rollout.n': 4,
        'actor_rollout_ref.rollout.temperature': 1.0,
        'actor_rollout_ref.rollout.tensor_model_parallel_size': 1,
        'actor_rollout_ref.rollout.gpu_memory_utilization': 0.25,
        'actor_rollout_ref.rollout.enforce_eager': True,
        'actor_rollout_ref.rollout.max_model_len': 2048,
        'actor_rollout_ref.rollout.max_num_seqs': 4,
        'actor_rollout_ref.rollout.max_num_batched_tokens': 4096,
        'actor_rollout_ref.rollout.enable_chunked_prefill': False,
        'actor_rollout_ref.rollout.enable_prefix_caching': False,
        'actor_rollout_ref.rollout.load_format': 'safetensors',
        'actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu': 1,
        'actor_rollout_ref.rollout.checkpoint_engine.backend': 'naive',
        'actor_rollout_ref.rollout.checkpoint_engine.update_weights_bucket_megabytes': 256,
        'actor_rollout_ref.rollout.engine_kwargs.vllm': {
            'language_model_only': True, 'generation_config': 'vllm',
        },
        'actor_rollout_ref.rollout.agent.num_workers': 4,
        'reward.num_workers': 4,
        'reward.reward_model.enable': False,
        'reward.reward_model.rollout.name': 'vllm',
        'transfer_queue.enable': True,
        'transfer_queue.backend.SimpleStorage.num_data_storage_units': 2,
        'transfer_queue.backend.SimpleStorage.total_storage_size': 4096,
        'trainer.use_v1': True, 'trainer.v1.trainer_mode': 'sync',
        'trainer.device': 'npu', 'trainer.nnodes': 1, 'trainer.n_gpus_per_node': 8,
        'trainer.total_epochs': 1, 'trainer.total_training_steps': steps,
        'trainer.project_name': 'f00951948_verl91',
        'trainer.experiment_name': run_dir.name,
        'trainer.logger': ['console', 'file', 'tensorboard'],
        'trainer.val_before_train': False,
        'trainer.test_freq': steps,
        'trainer.save_freq': min(5, steps),
        'trainer.max_actor_ckpt_to_keep': 2,
        'trainer.default_local_dir': str(run_dir / 'checkpoints'),
        'trainer.resume_mode': 'auto',
        'trainer.rollout_data_dir': str(run_dir / 'rollouts'),
        'trainer.validation_data_dir': str(run_dir / 'validation'),
        'ray_kwargs.ray_init.address': 'local',
        'ray_kwargs.ray_init.namespace': 'f00951948_verl91_grpo',
        'ray_kwargs.ray_init.num_cpus': 64,
        'ray_kwargs.ray_init.num_gpus': 0,
        'ray_kwargs.ray_init.resources': {'NPU': 8},
        'ray_kwargs.ray_init.include_dashboard': False,
        'ray_kwargs.ray_init.object_store_memory': 1024 * 1024 * 1024,
        'ray_kwargs.ray_init._node_ip_address': '127.0.0.1',
        'ray_kwargs.ray_init._temp_dir': str(W / 'tmp/r30'),
        'ray_kwargs.ray_init.runtime_env.py_executable': str(W / 'envs/verl91/bin/python'),
        'ray_kwargs.ray_init.runtime_env.env_vars': env,
    }
    for key, value in overrides.items():
        OmegaConf.update(cfg, key, value, merge=False, force_add=True)
    validate_config(cfg, use_reference_policy=need_reference_policy(cfg), use_critic=need_critic(cfg))
    assert need_reference_policy(cfg) and not need_critic(cfg)
    actor = omega_conf_to_dataclass(cfg.actor_rollout_ref.actor)
    rollout = omega_conf_to_dataclass(cfg.actor_rollout_ref.rollout)
    model = omega_conf_to_dataclass(cfg.actor_rollout_ref.model)
    assert actor.engine.strategy == 'fsdp2' and not actor.engine.use_torch_compile
    assert actor.optim.override_optimizer_config == {'foreach': False, 'fused': False}
    assert rollout.tensor_model_parallel_size == 1 and rollout.n == 4
    assert CheckpointEngineRegistry.get('naive') is not None
    assert get_trainer_cls('sync') is not None

    # The actual trainer supplies the multimodal processor even for text-only data.
    for split in ('train', 'val'):
        loaded = RLHFDataset(
            data_files=cfg.data[f'{split}_files'], tokenizer=model.tokenizer,
            processor=model.processor, config=cfg.data,
        )
        assert len(loaded) == data['files'][split]['rows']
        prompt = loaded[0]['raw_prompt']
        formatter = model.processor if model.processor is not None else model.tokenizer
        rendered = formatter.apply_chat_template(
            prompt, tokenize=False, add_generation_prompt=True, enable_thinking=False,
        )
        reference = model.tokenizer.apply_chat_template(
            pq.read_table(data['files'][split]['path']).to_pylist()[0]['prompt'],
            tokenize=False, add_generation_prompt=True, enable_thinking=False,
        )
        assert rendered == reference, f'{split}的Processor和Tokenizer文本模板不一致'
    stable_overrides = dict(overrides)
    stable_overrides['ray_kwargs.ray_init.runtime_env.env_vars'] = {
        k: v for k, v in env.items() if k != 'PYTHONPATH'
    }
    profile = {
        'steps': steps, 'model': str(MODEL), 'overrides': stable_overrides,
        'baseline_protocol': baseline['protocol_fingerprint'],
        'data_sha256': {k: v['sha256'] for k, v in data['files'].items()},
    }
    old_profile = run_dir / 'profile.json'
    if old_profile.exists():
        assert json.loads(old_profile.read_text()) == profile, '同名训练任务配置发生变化，请使用新的run-name'
    else:
        write_json(old_profile, profile)
    OmegaConf.save(cfg, str(run_dir / 'config.yaml'), resolve=False)
    write_json(run_dir / 'baseline_reference.json', baseline)
    write_json(run_dir / 'preflight.json', {
        'passed': True, 'steps': steps, 'need_reference': True, 'need_critic': False,
        'train_rows': 7217, 'val_rows': 256,
        'processor_template_check_passed': True,
        'npu_ipc_supported': is_support_ipc(),
        'launcher_sha256': sha_file(Path(__file__)),
        'training_started': False,
    })
    print(f'GRPO配置、模块与数据预检通过：8卡，{steps}步，每步16题，每题4个回答', flush=True)
    print('学习率=1e-6，Actor/Reference=FSDP2，Rollout=vLLM-Ascend TP1', flush=True)
    print('配置文件：', run_dir / 'config.yaml', flush=True)
    return cfg


def check_results(run_dir, steps):
    by_step = {}
    sources = sorted((run_dir / 'attempts').glob('metrics_*.jsonl')) + [run_dir / 'metrics.jsonl']
    for path in sources:
        if not path.exists():
            continue
        for line in path.read_text().splitlines():
            if line.strip():
                row = json.loads(line)
                if int(row['step']) > 0:
                    by_step[int(row['step'])] = row['data']
    assert set(range(1, steps + 1)) <= set(by_step), '训练指标尚未覆盖全部目标步数'
    checked = []
    for step in range(1, steps + 1):
        values = by_step[step]
        loss = float(values['actor/pg_loss'])
        norm = float(values['actor/grad_norm'])
        assert math.isfinite(loss) and math.isfinite(norm), f'第{step}步Loss或梯度范数非有限'
        checked.append({'step': step, 'pg_loss': loss, 'grad_norm': norm,
                        'reward': values.get('critic/score/mean')})
    assert any(row['grad_norm'] > 0 for row in checked), '所有训练步的梯度范数均为零，需要检查奖励差异'
    checkpoint = run_dir / 'checkpoints' / f'global_step_{steps}'
    for prefix in ('model', 'optim', 'extra_state'):
        for rank in range(8):
            p = checkpoint / 'actor' / f'{prefix}_world_size_8_rank_{rank}.pt'
            assert p.is_file() and p.stat().st_size > 0, f'检查点文件缺失：{p}'
    assert (checkpoint / 'data.pt').is_file(), '缺少数据加载器检查点'
    write_json(run_dir / 'training_complete.json', {
        'passed': True, 'completed_steps': steps,
        'time_utc': datetime.now(timezone.utc).isoformat(),
        'checkpoint': str(checkpoint), 'step_metrics': checked,
        'checkpoint_reload_tested': False, 'post_training_gsm8k_evaluated': False,
    })
    print(f'GRPO {steps}步及检查点保存检查通过', flush=True)
    print('最终检查点：', checkpoint, flush=True)
    print('后续需合并检查点、验证重新加载，并按基线协议复测GSM8K', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--steps', type=int, default=10)
    parser.add_argument('--run-name', default='grpo10')
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    assert args.steps > 0 and re.fullmatch(r'[A-Za-z0-9_-]{1,64}', args.run_name)
    root = W / 'runs'
    root.mkdir(exist_ok=True)
    run_dir = root / f'qwen35_{args.run_name}'
    run_dir.mkdir(exist_ok=True)
    env = setup_env(run_dir)
    with (root / '.grpo_training.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('当前已有本工作区的GRPO启动程序在运行') from exc
        cfg = prepare(run_dir, args.steps, env)
        if args.prepare_only:
            print('仅完成CPU配置与数据预检，尚未启动Ray或模型训练', flush=True)
            return
        if args.check_only or (run_dir / 'training_complete.json').exists():
            check_results(run_dir, args.steps)
            return
        smi = subprocess.run(['npu-smi', 'info'], text=True, capture_output=True, timeout=30)
        info = smi.stdout + smi.stderr
        (run_dir / 'npu_before.log').write_text(info)
        idle = {int(x) for x in re.findall(r'No running processes found in NPU\s+(\d+)', info)}
        assert smi.returncode == 0 and idle == set(range(8)), '八张卡未确认空闲，请查看npu_before.log'
        if (run_dir / 'metrics.jsonl').exists():
            attempts = run_dir / 'attempts'
            attempts.mkdir(exist_ok=True)
            shutil.copy2(run_dir / 'metrics.jsonl', attempts / f'metrics_{time.time_ns()}.jsonl')
        import ray
        from verl.trainer.main_ppo import main as verl_main

        def stop(signum, frame):
            raise KeyboardInterrupt('训练启动程序收到停止信号')

        for sig in (signal.SIGTERM, signal.SIGHUP):
            signal.signal(sig, stop)
        write_json(run_dir / 'launch.json', {
            'driver_pid': os.getpid(), 'time_utc': datetime.now(timezone.utc).isoformat(),
            'steps': args.steps, 'ray_address_mode': 'local',
        })
        try:
            print('开始执行VERL同步GRPO训练……', flush=True)
            verl_main(cfg)
        finally:
            ray.shutdown()
            print('本次GRPO的Ray实例已关闭', flush=True)
        check_results(run_dir, args.steps)


if __name__ == '__main__':
    main()
