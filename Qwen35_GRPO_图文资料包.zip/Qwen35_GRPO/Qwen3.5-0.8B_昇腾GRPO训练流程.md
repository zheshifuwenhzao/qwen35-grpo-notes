# 昇腾 910B3 上的 Qwen3.5-0.8B GRPO 训练流程

本实验在单台服务器的 8 张 Ascend 910B3 上，用 CANN 9.1.0、VERL 0.9.1、FSDP2 和 vLLM-Ascend，对 Qwen3.5-0.8B 运行 GSM8K 的 GRPO 训练。首次训练已完成 10 步并保存检查点。随后直接调用 VERL Python 入口的独立重跑，已有 `step:4`、`4/10` 的运行记录。训练后的完整测试准确率以第 32 步生成的对比报告为准。

| 大块 | 步骤 | 实际工作和验收 |
|---|---|---|
| 一、驱动检查、容器和 Python | 01–04 | 核对并复用宿主机驱动与固件，创建 Ubuntu 容器，准备 Conda Python 3.12 |
| 二、CANN 安装和激活 | 05–10 | 下载并校验 Toolkit、910B Ops 和 NNAL，安装 ATB，验证 ACL 可见八卡 |
| 三、PTA 安装和验收 | 11–12 | 安装 PyTorch 与 TorchNPU，验证 NPU 上的 FP32、BF16 前向与反向 |
| 四、原始权重下载和校验 | 13–15 | 安装 Transformers，下载 Qwen3.5-0.8B 的 Safetensors，校验 SHA256 并测试单卡前向、反向 |
| 五、框架环境和多卡验证 | 16–27 | 安装 Triton-Ascend、vLLM、vLLM-Ascend 和 VERL，验证 Ray、HCCL 与 FSDP2 更新 |
| 六、数据准备和基线评测 | 28–29 | 划分 GSM8K，验证严格评分，记录原模型测试基线 48.22% |
| 七、GRPO 训练和权重导出 | 30–32 | 启动八卡 GRPO，查看每步指标，合并训练检查点并用同一协议复测 |

PTA 指 PyTorch 的昇腾适配层，本实验对应 `torch_npu`。`PATH`、`PYTHONPATH` 和 CANN 环境变量属于环境激活。原始模型下载的是可直接加载的 Safetensors。第 31 步将训练产生的 FSDP 检查点合并为可加载的模型目录。

[从昇腾 CANN 官网首页进入安装指导](#从昇腾-cann-官网首页进入安装指导)。官网和项目截图放在对应步骤中，红框标出原网页里的入口、命令、版本或接口。驱动与 CANN 部分区分昇腾社区原文、vLLM-Ascend 项目示例和本机改写；整套训练参数是本实验配置。

## 实验环境与复现材料

| 项目 | 本次实际使用 |
|---|---|
| 宿主机 | ARM64，openEuler 22.03 LTS-SP4，复用既有驱动 `25.5.1` 和固件 `7.7.0.1.231` |
| 容器 | `f00951948_cann91`，`ubuntu:22.04` 基础镜像，容器系统为 Ubuntu 22.04.5 |
| 项目目录与 Python | `/data1/f00951948_cann91`，Conda 环境 `envs/verl91`，Python `3.12.16` |
| CANN | Toolkit `9.1.0`、910B Ops `9.1.0`、NNAL 内 ATB `9.1.0.B150` |
| PyTorch | `torch 2.10.0+cpu`、`torch_npu 2.10.0.post4`、`torchvision 0.25.0+cpu`、`torchaudio 2.10.0+cpu` |
| 模型和算子 | `transformers 5.5.4`、`numpy 1.26.4`、`triton-ascend 3.2.2`、`triton 3.5.0` 发行包 |
| 推理 | `vllm 0.23.0+empty`、`vllm-ascend 0.23.0.post1`，均从源码以 editable 方式安装 |
| 强化学习 | `verl 0.9.1`、`ray 2.48.0`、`TransferQueue 0.1.10`，V1 同步训练 |
| 模型与数据 | Qwen3.5-0.8B 的固定 ModelScope 提交，GSM8K 的固定 Hugging Face 提交 |

宿主机负责设备和驱动。CANN 用户态组件、Python、框架、模型和数据装在容器及其挂载目录。PyTorch 的 `+cpu` 是基础发行包标签，NPU 计算由配套的 `torch_npu` 和 CANN 提供，实际用卡由第 12 步的张量设备与计算结果核验。

在已有实验服务器上继续训练，可以完成第 02 步的容器进入和第 10 步的环境激活，随后执行第 30 步。整套重建按顺序执行。第 01–18 步按安装依赖顺序展开，历史日志文件名保留原编号。

新容器复现时，先将原实验目录的 `packages/`、`records/`、`scripts/` 及源码构建输入备份并迁移到同一绝对路径。依赖库存在本地兼容调整，第 19、20、24 步给出对应处理。保留依赖锁、校验表和原始源码归档，才能复用当时的解析与构建输入。当前工作区附带 [VERL 依赖锁](23_verl_deps.lock.txt)、[完整训练 YAML](30_grpo_config.yaml) 和 [第 30 步启动脚本](30_run_grpo.py)。完整 wheel 缓存、安装报告和 CANN 包在实验服务器上。

| 服务端路径（相对项目目录） | 用途 |
|---|---|
| `packages/`、`packages/16_triton_wheels/` | CANN、Miniconda、PyTorch 和 Triton 安装包 |
| `packages/19_vllm_wheels/`、`records/19_vllm_deps.lock.txt`、`records/19_vllm_wheels_sha256.txt` | vLLM 依赖及离线校验 |
| `src/vllm-0.23.0/`、`src/vllm_ascend-0.23.0.post1/`、`records/21_ascend_build_inputs_sha256.txt` | 主体、Ascend 插件源码和缓存的 C++ 构建输入，包括 CATLASS |
| `packages/23_verl_wheels/`、`packages/23_verl_sources/verl-0.9.1.tar.gz` | VERL 依赖和原始源码归档 |
| `records/`、`logs/` | 包版本、校验表、补丁、分层验证记录与终端日志 |
| `scripts/` | 环境检查、数据处理、评测、训练和导出脚本 |
| `runs/`、`eval/gsm8k/` | 训练检查点、每步日志、逐题预测和评测报告 |

## 一、驱动检查、容器和 Python

### 从昇腾 CANN 官网首页进入安装指导

起点是[昇腾 CANN 官网首页](https://www.hiascend.com/cann)。图 00a 是首页上的架构图和导航。底部「驱动」对应本实验宿主机的 NPU 驱动与设备检查；「运行时」「算子库」等与容器中安装的 CANN 组件对应；「AI 框架适配」在本实验对应 PyTorch 的 TorchNPU。vLLM-Ascend、VERL 和 GRPO 参数要查各项目的文档或本实验配置。首页架构图用来说明层次，命令到下一层页面查。

![图 00a，CANN 官网首页的下载、文档入口，以及架构图中的框架适配与驱动](official-screenshots/00a-cann-homepage.png)

**本实验的命令对照入口：** 首页点[文档](https://www.hiascend.com/cann/document) → 版本切换到「9.1.X」→「发行与安装」→「软件安装」→ [选择安装场景](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0000.html?OS=openEuler&InstallType=local) →「离线安装（驱动 & Toolkit 独立包）」。左侧可点[安装 NPU 驱动和固件](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0005.html?OS=openEuler&InstallType=local)或[安装 CANN](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0008.html?OS=openEuler&InstallType=local)。安装 CANN 时，Ops 选「Atlas A2 系列产品」及 `aarch`（即 ARM64），页面显示 `910b-ops`。第 01、07、08、09 步的昇腾官网安装截图均从这条路径取得。宿主机是 openEuler；本次实际把三个 CANN 用户态包手工装在 Ubuntu 容器内，驱动留在宿主机，具体执行命令见正文。

![图 00c，CANN 9.1.X 文档页的软件安装入口及独立包选项](official-screenshots/00c-cann-install-navigation.png)

### 01 核对宿主机与 NPU

在宿主机执行。记录系统、CPU 架构、驱动、固件、八卡状态和数据盘空间。`Compatibility=OK` 反映驱动与固件配对，运行时验收由第 10 步完成。本次复用宿主机既有驱动和固件，仅执行检查；如需在新机器上从零安装，先按具体服务器型号和配套版本查阅[昇腾社区《安装 NPU 驱动和固件》](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0005.html?OS=openEuler&InstallType=local)。查询板卡版本命令见[昇腾社区《查询软件包版本信息》](https://www.hiascend.com/doc_center/source/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0064.html)。

```bash
uname -m
cat /etc/os-release
uname -r
npu-smi info
npu-smi info -t board -i 0
cat /usr/local/Ascend/driver/version.info
docker version --format '{{.Server.Version}}'
docker image inspect ubuntu:22.04 --format '{{.Id}}'
df -h / /data1
```

**官网命令对照：** `npu-smi info` 用于核对驱动是否已加载；板卡版本查询示例中的 `id` 在本实验替换为 `0`。这一步在宿主机执行。

![步骤 01：昇腾官网驱动与固件指南，红框标出 npu-smi info](official-screenshots/01a-hiascend-driver-guide.png)

![步骤 01：官网用 npu-smi 查询板卡驱动和固件版本](official-screenshots/01-board-version.png)

### 02 创建或进入独立容器

已有容器时，在宿主机检查状态，按需启动，再进入。

```bash
docker inspect f00951948_cann91 --format '{{.State.Status}} {{.Config.Image}}'
# 状态是 exited 时执行 docker start f00951948_cann91
docker exec -it f00951948_cann91 bash
```

从基础镜像新建时，在宿主机执行下面一段。设备与系统驱动只读挂载，数据盘可写。八卡测试和训练使用已分配给本实验且空闲的设备。

```bash
export VERL_WORK=/data1/f00951948_cann91
mkdir -p "$VERL_WORK"/{packages,src,models,data,logs,records,scripts,tmp,.cache}

docker run -d --name f00951948_cann91 --runtime=runc --network=host \
  --shm-size=64g --ulimit memlock=-1 --ulimit stack=67108864 \
  --device=/dev/davinci0 --device=/dev/davinci1 --device=/dev/davinci2 \
  --device=/dev/davinci3 --device=/dev/davinci4 --device=/dev/davinci5 \
  --device=/dev/davinci6 --device=/dev/davinci7 \
  --device=/dev/davinci_manager --device=/dev/devmm_svm --device=/dev/hisi_hdc \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro \
  -v /usr/local/dcmi:/usr/local/dcmi:ro \
  -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi:ro \
  -v /etc/ascend_install.info:/etc/ascend_install.info:ro \
  -v "$VERL_WORK:$VERL_WORK" -w "$VERL_WORK" \
  -e ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
  -e LD_LIBRARY_PATH=/usr/local/dcmi:/usr/local/Ascend/driver/lib64:/usr/local/Ascend/driver/lib64/common:/usr/local/Ascend/driver/lib64/driver \
  -e TMPDIR="$VERL_WORK/tmp" \
  -e PIP_CACHE_DIR="$VERL_WORK/.cache/pip" \
  -e HF_HOME="$VERL_WORK/.cache/huggingface" \
  ubuntu:22.04 sleep infinity

docker exec -it f00951948_cann91 bash
```

### 03 安装 Ubuntu 基础工具

从这里开始在容器内执行。项目目录同时挂载到宿主机和容器，因此用 `/.dockerenv` 和 `/etc/os-release` 核对运行位置。

```bash
test -f /.dockerenv && cat /etc/os-release
export VERL_WORK=/data1/f00951948_cann91
cd "$VERL_WORK"
mkdir -p packages src models data logs records scripts tmp .cache/pip .cache/conda/pkgs
export TMPDIR="$VERL_WORK/tmp"
export PIP_CACHE_DIR="$VERL_WORK/.cache/pip"
export CONDA_PKGS_DIRS="$VERL_WORK/.cache/conda/pkgs"
set -o pipefail

(
  set -e
  test -f /.dockerenv
  apt-get -o Acquire::Retries=3 -o Acquire::http::Timeout=30 update \
    2>&1 | tee logs/01_apt_update.log
  DEBIAN_FRONTEND=noninteractive apt-get \
    -o Acquire::Retries=3 -o Acquire::http::Timeout=30 install -y \
    build-essential cmake ninja-build pkg-config git curl wget jq vim ca-certificates \
    libnuma-dev libffi-dev libssl-dev zlib1g-dev bzip2 unzip xz-utils \
    python3 python3-pip python3-dev python3-venv iproute2 iputils-ping procps less util-linux \
    2>&1 | tee logs/02_apt_install.log
  gcc -dumpfullversion
  git --version
  python3 --version
)
```

### 04 安装 Miniconda 并创建训练环境

安装包使用 ARM64 版本。缓存文件已存在时可直接校验。Conda 的初始环境包清单可用于将来重建时锁定解析结果。[Miniconda 官方归档](https://repo.anaconda.com/miniconda/)

```bash
(
  set -e
  test -f /.dockerenv
  cd "$VERL_WORK/packages"
  installer=Miniconda3-py312_26.9.4-0-Linux-aarch64.sh
  if ! test -f "$installer"; then
    curl -fL --retry 3 -o "$installer.part" "https://repo.anaconda.com/miniconda/$installer"
    mv "$installer.part" "$installer"
  fi
  printf '%s\n' \
    '533d8b855c6051a73433e70075546f72e6592cb40f0842a72bdd6992bfd6b021  Miniconda3-py312_26.9.4-0-Linux-aarch64.sh' \
    | sha256sum -c -
  bash "$installer" -b -p "$VERL_WORK/miniconda3" \
    2>&1 | tee "$VERL_WORK/logs/03_miniconda_install.log"
)
```

Miniconda 安装成功后，创建独立环境。迁移了原始 Conda 包清单时优先用它。

```bash
source "$VERL_WORK/miniconda3/etc/profile.d/conda.sh"
if test -s "$VERL_WORK/records/conda_initial_packages.txt"; then
  conda create -y --prefix "$VERL_WORK/envs/verl91" \
    --file "$VERL_WORK/records/conda_initial_packages.txt" \
    2>&1 | tee "$VERL_WORK/logs/04_python_env_create.log"
else
  conda create -y --prefix "$VERL_WORK/envs/verl91" --override-channels \
    -c conda-forge python=3.12.16 pip=26.2.2 \
    2>&1 | tee "$VERL_WORK/logs/04_python_env_create.log"
fi
```

环境创建成功后执行。

```bash
conda activate "$VERL_WORK/envs/verl91"

python --version
python -m pip --version
printf '%s\n' "$CONDA_PREFIX"
if ! test -s "$VERL_WORK/records/conda_initial_packages.txt"; then
  conda list --explicit > "$VERL_WORK/records/conda_initial_packages.txt"
fi
```

## 二、CANN 安装和激活

### 05 下载并校验 CANN 9.1.0

```bash
cd "$VERL_WORK/packages"
cann_repo='https://ascend-repo.obs.cn-east-2.myhuaweicloud.com/CANN/CANN%209.1.0'
for installer in Ascend-cann-toolkit_9.1.0_linux-aarch64.run \
                 Ascend-cann-910b-ops_9.1.0_linux-aarch64.run \
                 Ascend-cann-nnal_9.1.0_linux-aarch64.run; do
  if ! test -f "$installer"; then
    curl -fL --retry 3 -C - --referer https://www.hiascend.com/ \
      -o "$installer.part" "$cann_repo/$installer" || break
    mv "$installer.part" "$installer"
  fi
done

sha256sum -c - <<'SHA256' | tee "$VERL_WORK/logs/05_cann91_checksums.log"
ccfa4249422eb60355e425e89a8bddeaf27fd91575ea805334e7e74d7518abd2  Ascend-cann-toolkit_9.1.0_linux-aarch64.run
f57d48539e4b33033b81396478ffb757a373e9aa0addc4b99f150d477c14e6aa  Ascend-cann-910b-ops_9.1.0_linux-aarch64.run
62a79f474280eecdc5a584d78036a2074ad740369150e9403f260655307d86e1  Ascend-cann-nnal_9.1.0_linux-aarch64.run
SHA256
```

三个包都显示 `OK` 后继续。[昇腾社区 CANN 9.1.X 安装指南](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0008.html?OS=openEuler&InstallType=local)列出这些 ARM64 软件包和下载地址，Ops 选 Atlas A2 的 910B 包。官网用 `wget`，本实验改用支持重试和断点续传的 `curl`，并按实验留档校验 SHA256。

**快速安装入口：** 首页点「快速开始」或顶栏「下载」，进入[CANN 快速安装](https://www.hiascend.com/cann/download?versionId=796&ids=d802%2Ch0501%2Ch0601%2Ch0703&currentTab=0)。按宿主机筛选为「稳定版本 → 9.1.0 → A2 系列产品 → AArch64 → openEuler → 离线安装（Runfile）」。后续安装内容在页面上由软件许可协议控制；下图是未勾选时的筛选状态。按[官网快速安装 FAQ](https://www.hiascend.com/doc_center/source/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0050.html)，该入口的 Runfile 路线使用驱动和 Toolkit 合一包加 Ops 包。本实验单独安装 Toolkit、Ops 和 NNAL，第 07–09 步对照的是独立包文档。

![图 00b，CANN 快速安装页选定的 9.1.0、A2、AArch64、openEuler 和 Runfile](official-screenshots/00b-cann-quick-install.png)

### 06 安装 CANN 的 Python 基础依赖

```bash
cd "$VERL_WORK"
python -m pip install "numpy==1.26.4" "setuptools==80.10.2" \
  attrs decorator sympy cffi pyyaml pathlib2 psutil protobuf scipy \
  requests absl-py wheel typing_extensions packaging \
  2>&1 | tee logs/06_cann_python_dependencies.log
```

### 07 安装 Toolkit

```bash
(
  set -e
  test -f /.dockerenv
  test "$CONDA_PREFIX" = "$VERL_WORK/envs/verl91"
  cd "$VERL_WORK/packages"
  bash Ascend-cann-toolkit_9.1.0_linux-aarch64.run --check
  bash Ascend-cann-toolkit_9.1.0_linux-aarch64.run \
    --full --quiet --install-for-all --install-path=/usr/local/Ascend
) 2>&1 | tee "$VERL_WORK/logs/07_toolkit_install.log"

source /usr/local/Ascend/cann/set_env.sh
printf '%s\n' "$ASCEND_HOME_PATH" "$ASCEND_TOOLKIT_HOME"
```

实际安装路径应指向 `/usr/local/Ascend/cann-9.1.0`。这段保留本次容器里跑通的写法。Toolkit 的 `--full` 来自 [vLLM-Ascend 手工安装示例](https://docs.vllm.ai/projects/ascend/en/v0.23.0/installation.html#configure-software-environment)，[昇腾社区 CANN 安装示例](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0008.html?OS=openEuler&InstallType=local)使用的是 `--install`。容器检查、`--check`、非交互选项、安装路径和日志留档是实验命令中加的，整行不是官网原样示例。

![步骤 07：昇腾官网 Toolkit 安装示例，红框标出 --install 和环境脚本](official-screenshots/07-toolkit-official.png)

![步骤 07：vLLM-Ascend 手工安装示例，红框标出本实验采用的 --full](official-screenshots/07-toolkit-vllm.png)

![步骤 07：昇腾官网安装参数表对 Toolkit --full 的说明](official-screenshots/02c-hiascend-toolkit-full.png)

### 08 安装 910B Ops

沿用[昇腾社区的 Atlas A2 / ARM64 Ops 安装方式](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0008.html?OS=openEuler&InstallType=local)及其 `--install`，加上本实验的容器检查、安装选项和日志。

```bash
(
  set -e
  test -f /.dockerenv
  cd "$VERL_WORK/packages"
  bash Ascend-cann-910b-ops_9.1.0_linux-aarch64.run \
    --install --quiet --install-for-all
) 2>&1 | tee "$VERL_WORK/logs/08_ops_install.log"
```

![步骤 08：昇腾官网 Atlas A2 的 910B ARM64 Ops 安装命令](official-screenshots/08-910b-ops-official.png)

### 09 安装 NNAL 中的 ATB

NNAL 基础安装命令见[昇腾社区 CANN 安装指南](https://www.hiascend.com/document/detail/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0008.html?OS=openEuler&InstallType=local)。本实验按[官方参数表](https://www.hiascend.com/doc_center/source/en/CANNCommunityEdition/910/softwareinst/instg/instg_0043.html)添加 `--whitelist=atb`，并按容器实际路径激活和查询版本。

```bash
(
  set -e
  test -f /.dockerenv
  cd "$VERL_WORK/packages"
  bash Ascend-cann-nnal_9.1.0_linux-aarch64.run \
    --install --quiet --install-for-all --whitelist=atb
) 2>&1 | tee "$VERL_WORK/logs/09_atb_install.log"

source /usr/local/Ascend/nnal/atb/set_env.sh
bash /usr/local/Ascend/cann/query_pkg_version.sh
cat /usr/local/Ascend/nnal/atb/latest/version.info
```

本次组件检查得到 Ops `9.1.0`、ATB `9.1.0.B150`。安装 ATB 时曾回到宿主机，容器检查拦截了安装。修复方式是重新 `docker exec` 进入容器并激活 Conda、Toolkit，再重跑第 09 步。

![步骤 09：昇腾官网 ARM64 的 NNAL 安装与 ATB 环境脚本](official-screenshots/09-nnal-official.png)

![步骤 09：昇腾官网参数表说明 atb 白名单只安装 ATB](official-screenshots/02b-atb-flag.png)

[昇腾官网《查询软件包版本信息》](https://www.hiascend.com/doc_center/source/zh/CANNCommunityEdition/910/softwareinst/instg/instg_0064.html)演示的是非 root 用户路径；上面的命令换成容器中的 `/usr/local/Ascend`。

![步骤 09：昇腾官网查询 CANN 组件和 ATB 版本的命令](official-screenshots/09-cann-atb-version.png)

### 10 激活运行环境并验证 ACL

每次重新打开容器终端，都先执行下面的激活段。需要八卡的命令共用这些设备和 HCCL 设置。

```bash
export VERL_WORK=/data1/f00951948_cann91
cd "$VERL_WORK"
test -f /.dockerenv
source "$VERL_WORK/miniconda3/etc/profile.d/conda.sh"
conda activate "$VERL_WORK/envs/verl91"
source /usr/local/Ascend/cann/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh

export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
export OMP_NUM_THREADS=4 HCCL_CONNECT_TIMEOUT=600 HCCL_EXEC_TIMEOUT=600
set -o pipefail

command -v python
printf '%s\n' "$CONDA_PREFIX" "$ASCEND_TOOLKIT_HOME"
```

```bash
python -u - <<'PY' 2>&1 | tee logs/10_acl_check.log
import acl

assert acl.init() == 0
try:
    count, status = acl.rt.get_device_count()
    assert status == 0 and count == 8, (count, status)
    print("可见 NPU 数量", count, "芯片", acl.get_soc_name())
finally:
    assert acl.finalize() == 0
PY
```

## 三、PTA 安装和验收

### 11 安装固定版本的 PyTorch 和 torch_npu

实际安装使用保留的 ARM64、CPython 3.12 离线包。需要补包时，PyTorch 的 `+cpu` wheel 取自 PyTorch CPU 源，`torch_npu` 使用匹配的昇腾 wheel，并与原记录核对。后续依赖安装沿用已验收的 PyTorch 版本。[Ascend PyTorch 配套表](https://github.com/Ascend/pytorch/blob/master/COMPATIBILITY.md)

```bash
python -m pip install --no-index --find-links="$VERL_WORK/packages" \
  --only-binary=:all: --report records/11_torch_install_offline_report.json \
  "torch==2.10.0+cpu" "torch_npu==2.10.0.post4" \
  "torchvision==0.25.0+cpu" "numpy==1.26.4" \
  2>&1 | tee logs/11_torch_install_offline.log
```

**版本依据：** [vLLM-Ascend 版本要求](https://docs.vllm.ai/projects/ascend/en/v0.23.0/installation.html#requirements)列出 CANN `9.1.0`、TorchNPU `2.10.0.post4` 和 PyTorch `2.10.0`。本实验用已校验的 ARM64 离线 wheel 安装，是否实际用上 NPU 由下一步计算测试验证。

![步骤 11：vLLM-Ascend 的 CANN、TorchNPU 和 PyTorch 版本要求](official-screenshots/03-pta-versions.png)

### 12 验证 NPU 基础前向与反向

```bash
python -u - <<'PY' 2>&1 | tee logs/12_torch_npu_check.log
import torch
import torch_npu

assert torch.npu.is_available() and torch.npu.device_count() == 8
torch.npu.set_device(0)

for dtype in (torch.float32, torch.bfloat16):
    left = torch.tensor([[1., 2.], [3., 4.]], device="npu:0", dtype=dtype, requires_grad=True)
    right = torch.tensor([[5., 6.], [7., 8.]], device="npu:0", dtype=dtype)
    product = left @ right
    product.float().sum().backward()
    torch.npu.synchronize()
    torch.testing.assert_close(product.detach().float().cpu(), torch.tensor([[19., 22.], [43., 50.]]))
    torch.testing.assert_close(left.grad.float().cpu(), torch.tensor([[11., 15.], [11., 15.]]))
    print(dtype, product.device, "前向和反向通过")
PY
```

## 四、原始权重下载和校验

### 13 安装支持 Qwen3.5 的 Transformers

```bash
cat > records/constraints-qwen35-base.txt <<'EOF'
torch==2.10.0+cpu
torch_npu==2.10.0.post4
torchvision==0.25.0+cpu
numpy==1.26.4
setuptools==80.10.2
transformers==5.5.4
EOF

python -m pip install --index-url https://repo.huaweicloud.com/repository/pypi/simple \
  --only-binary=:all: -c records/constraints-qwen35-base.txt \
  --report records/13_transformers_install_report.json "transformers==5.5.4"

python - <<'PY'
import transformers
from transformers import Qwen3_5Config, Qwen3_5ForConditionalGeneration

assert transformers.__version__ == "5.5.4"
assert Qwen3_5Config.model_type == "qwen3_5"
print(Qwen3_5ForConditionalGeneration.__name__)
PY
```

### 14 下载并校验 Qwen3.5-0.8B

模型来自 Qwen 的 ModelScope 仓库，提交 `c62d4afcf135a7464a3e6743ee9454a6997291a1`。模型目录为 `models/Qwen3.5-0.8B/`。本次共核验 11 个文件，权重分片大小为 `1746942600` 字节，SHA256 为 `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`。[Qwen 模型卡](https://huggingface.co/Qwen/Qwen3.5-0.8B)

已有模型目录可与清单一起迁移。下面是从固定提交下载配置、分词器及权重的方式。下载前先核对清单内权重的固定校验值，已有文件校验通过时跳过。

```bash
python -u - <<'PY' 2>&1 | tee logs/14_qwen35_download.log
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

model = "Qwen/Qwen3.5-0.8B"
revision = "c62d4afcf135a7464a3e6743ee9454a6997291a1"
target = Path("models/Qwen3.5-0.8B")
target.mkdir(parents=True, exist_ok=True)
weight = "model.safetensors-00001-of-00001.safetensors"
names = (
    "LICENSE", "config.json", "chat_template.jinja", "merges.txt", "vocab.json",
    "tokenizer.json", "tokenizer_config.json", "preprocessor_config.json",
    "video_preprocessor_config.json", "model.safetensors.index.json", weight,
)
api = f"https://modelscope.cn/api/v1/models/{model}/repo/files?Revision={revision}&Recursive=true"
with urllib.request.urlopen(api, timeout=30) as response:
    manifest = json.load(response)
assert manifest["Code"] == 200
entries = {item["Path"]: item for item in manifest["Data"]["Files"]}
assert entries[weight]["Sha256"] == "04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696"
Path("records/14_qwen35_modelscope_manifest.json").write_text(
    json.dumps({"model_id": model, "revision": revision, "manifest": manifest}, indent=2)
)

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

for name in names:
    final = target / name
    info = entries[name]
    if final.is_file() and final.stat().st_size == info["Size"] and digest(final) == info["Sha256"]:
        continue
    partial = target / (name + ".part")
    if not partial.exists() or partial.stat().st_size < info["Size"]:
        url = f"https://modelscope.cn/models/{model}/resolve/{revision}/{name}"
        subprocess.run(["curl", "-fL", "--retry", "3", "-C", "-", "-o", str(partial), url], check=True)
    assert partial.stat().st_size == info["Size"] and digest(partial) == info["Sha256"], name
    partial.replace(final)
    print("校验通过", name)
assert set(json.loads((target / "model.safetensors.index.json").read_text())["weight_map"].values()) <= set(names)
PY
```

若权重单连接下载较慢，在小文件和清单已准备好之后，可以用 [分段下载脚本](download_qwen35_parallel.py) 续接权重下载。脚本会核验整份权重及其余模型文件。

[Qwen 官方 ModelScope 权重页](https://modelscope.cn/models/Qwen/Qwen3.5-0.8B/file/view/master/model.safetensors-00001-of-00001.safetensors)截图显示的是 `master` 上的文件；图中 SHA256 与本实验固定提交的实验记录一致。上面的下载命令使用固定提交。

![步骤 14：Qwen 官方权重文件和 SHA256](official-screenshots/05-modelscope-weight.png)

### 15 验证真实模型在单卡上的前向与反向

```bash
python -u - <<'PY' 2>&1 | tee logs/15_qwen35_model_check.log
import math
import torch
import torch_npu
from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration

path = "models/Qwen3.5-0.8B"
torch.npu.set_device(0)
tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
model = Qwen3_5ForConditionalGeneration.from_pretrained(
    path, dtype=torch.bfloat16, attn_implementation="eager", local_files_only=True
).to("npu:0")
model.train()
inputs = tokenizer("问题：1加1等于多少？答案：2。", return_tensors="pt").to("npu:0")
loss = model(**inputs, labels=inputs["input_ids"], use_cache=False).loss
assert torch.isfinite(loss).item()
loss.backward()
torch.npu.synchronize()
parameter = next(p for p in model.parameters() if p.grad is not None and p.ndim == 2 and p.numel() < 10_000_000)
norm = parameter.grad.float().norm().item()
assert math.isfinite(norm) and norm > 0
print("loss", loss.item(), "grad_norm", norm)
PY
```

本次短文本探针记录到 Loss `2.72354`、选定参数梯度范数 `40.24514`，退出码为 0。

## 五、框架环境和多卡验证

### 16 离线安装 Triton-Ascend

```bash
cp records/constraints-qwen35-base.txt records/constraints-qwen35-triton.txt
cat >> records/constraints-qwen35-triton.txt <<'EOF'
triton-ascend==3.2.2
triton==3.5.0
scipy==1.13.1
EOF

python -m pip install --no-index --find-links=packages/16_triton_wheels \
  --only-binary=:all: -c records/constraints-qwen35-triton.txt \
  --report records/16_triton_install_offline_report.json \
  "triton-ascend==3.2.2" "triton==3.5.0" \
  2>&1 | tee logs/16_triton_install_offline.log

python - <<'PY'
from importlib.metadata import version
import triton
from triton.backends import backends

print(version("triton-ascend"), version("triton"), triton.__version__, sorted(backends))
assert version("triton-ascend") == "3.2.2" and "ascend" in backends
PY
```

本次 `triton` 的发行包元数据显示 `3.5.0`，导入模块字符串显示 `3.2.0`。实际后端以导入检查和第 18 步执行结果为准。

### 17 补齐 vLLM 构建工具

```bash
python -m pip config --site set global.index-url \
  https://repo.huaweicloud.com/repository/pypi/simple

cat > records/17_ubuntu_huawei.list <<'EOF'
deb https://repo.huaweicloud.com/ubuntu-ports/ jammy main restricted universe multiverse
deb https://repo.huaweicloud.com/ubuntu-ports/ jammy-updates main restricted universe multiverse
deb https://repo.huaweicloud.com/ubuntu-ports/ jammy-security main restricted universe multiverse
EOF

apt_build_opts=(
  -o "Dir::Etc::sourcelist=$VERL_WORK/records/17_ubuntu_huawei.list"
  -o Dir::Etc::sourceparts=-
  -o Acquire::Retries=3
)
apt-get "${apt_build_opts[@]}" update
apt-get "${apt_build_opts[@]}" install -y --no-install-recommends \
  clang-15 numactl libnuma-dev libjemalloc2 libibverbs-dev libhiredis-dev

update-alternatives --install /usr/bin/clang clang /usr/bin/clang-15 20
update-alternatives --install /usr/bin/clang++ clang++ /usr/bin/clang++-15 20

python -m pip install -c records/constraints-qwen35-triton.txt \
  cmake==3.31.6 ninja==1.11.1.4 setuptools-scm==9.2.2 setuptools-rust==1.11.1
clang --version
cmake --version
ninja --version
```

### 18 运行 Triton NPU 算子测试

```bash
export TRITON_CACHE_DIR="$VERL_WORK/.cache/triton"
mkdir -p "$TRITON_CACHE_DIR"
if ! test -f scripts/18_triton_add_check.py; then
  cat > scripts/18_triton_add_check.py <<'PY'
import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def add_npu(left, right, output, count, TILE: tl.constexpr):
    offsets = tl.program_id(0) * TILE + tl.arange(0, TILE)
    valid = offsets < count
    a = tl.load(left + offsets, mask=valid, other=0)
    b = tl.load(right + offsets, mask=valid, other=0)
    tl.store(output + offsets, a + b, mask=valid)


def main():
    torch.npu.set_device(0)
    print("Triton目标：", triton.runtime.driver.active.get_current_target())

    # 1003不是256的整数倍，同时检查末尾边界处理
    count = 1003
    tile = 256

    for dtype in (torch.float32, torch.bfloat16):
        left_cpu = (torch.arange(count, dtype=torch.float32) % 16).to(dtype)
        right_cpu = torch.full((count,), 2.0, dtype=dtype)

        left = left_cpu.to("npu:0")
        right = right_cpu.to("npu:0")
        output = torch.empty_like(left)

        print(f"开始编译和执行：{dtype}", flush=True)

        add_npu[(triton.cdiv(count, tile),)](
            left, right, output, count, TILE=tile
        )
        torch.npu.synchronize()

        expected = left_cpu.float() + right_cpu.float()
        actual = output.float().cpu()

        torch.testing.assert_close(actual, expected, rtol=0, atol=0)

        difference = (actual - expected).abs().max().item()
        print(f"{dtype}：通过，设备={output.device}，最大误差={difference}")

    print("Triton NPU算子编译和执行检查通过")


if __name__ == "__main__":
    main()
PY
fi
python -u scripts/18_triton_add_check.py 2>&1 | tee logs/18_triton_add_check.log
```

测试脚本已保存在原服务器的 `scripts/`。它用 1003 个元素和 256 的分块大小，覆盖末尾掩码，分别核对 FP32 与 BF16。两种精度的最大误差均为 0。需要重建测试文件时，可按 [Triton-Ascend 向量加法示例](https://github.com/Ascend/triton-ascend/blob/main/third_party/ascend/tutorials/01-vector-add.py) 使用相同输入重做检查。

### 19 安装 vLLM 的锁定依赖

本次离线目录收录 121 个依赖文件。安装前先用随目录保存的校验表核对内容。Triton-Ascend 使用 NumPy 1.26.4，因此本实验锁定 `opencv-python-headless==4.11.0.86`。vLLM 主体对应的依赖声明调整在第 20 步完成。

```bash
cd "$VERL_WORK"

(
  set -e
  if ! test -f records/19_before_freeze.txt; then
    env -u PYTHONPATH python -m pip freeze > records/19_before_freeze.txt
  fi
  (cd packages/19_vllm_wheels && sha256sum --check --quiet ../../records/19_vllm_wheels_sha256.txt)

  python -m pip install --no-index --find-links=packages/19_vllm_wheels \
    -c records/constraints-qwen35-triton.txt \
    "nanobind==2.9.2" "grpcio-tools==1.85.1"

  export CC=/usr/bin/gcc CXX=/usr/bin/g++
  export CMAKE_BUILD_PARALLEL_LEVEL=8 MAX_JOBS=8
  export ARCTIC_INFERENCE_PRECOMPILED_OPS=0

  python -m pip install --no-index --no-build-isolation \
    --find-links=packages/19_vllm_wheels \
    -c records/constraints-qwen35-triton.txt -r records/19_vllm_deps.lock.txt
  env -u PYTHONPATH python -m pip check
  python -c 'import cv2, arctic_inference.suffix_decoding._C; print(cv2.__version__)'
) 2>&1 | tee logs/19_vllm_dependencies_install.log
```

本次检查确认核心版本保持不变，Arctic Inference 的本地编译扩展可以导入。原始版本快照在 `records/19_core_before.json`。

### 20 安装 vLLM 0.23.0 主体

从已核对的 `src/vllm-0.23.0/` 安装。这里用 `VLLM_TARGET_DEVICE=empty` 构建主体，由第 21 步的 Ascend 插件提供设备实现。源码的 OpenCV 声明从 `>=4.13.0` 调整为 `==4.11.0.86`，以匹配第 19 步的锁定版本。[vLLM-Ascend 源码安装说明](https://docs.vllm.ai/projects/ascend/en/v0.23.0/installation.html)

```bash
(
  set -e
  python - <<'PY'
import difflib
import hashlib
from pathlib import Path

source = Path("src/vllm-0.23.0/requirements/common.txt")
backup = Path("records/20_vllm_common.upstream.txt")
current = source.read_text()
original = backup.read_text() if backup.is_file() else current
expected = "c21fb3847783511dcd16fc5b6185a4e9d99aac28ec1562281f6877f2610412f8"
assert hashlib.sha256(original.encode()).hexdigest() == expected
before = "opencv-python-headless >= 4.13.0"
after = "opencv-python-headless == 4.11.0.86"
assert original.count(before) == 1
updated = original.replace(before, after)
assert current in (original, updated), "依赖文件已有其他修改"
if not backup.is_file():
    backup.write_text(original)
source.write_text(updated)
Path("records/20_vllm_dependencies.patch").write_text("".join(difflib.unified_diff(
    original.splitlines(keepends=True), updated.splitlines(keepends=True),
    fromfile="upstream/requirements/common.txt", tofile="local-npu/requirements/common.txt"
)))
PY

  VLLM_TARGET_DEVICE=empty VLLM_USE_PRECOMPILED=0 \
  VLLM_USE_PRECOMPILED_RUST=0 VLLM_REQUIRE_RUST_FRONTEND=0 \
    python -m pip install --no-index --no-deps --no-build-isolation \
      --verbose --editable src/vllm-0.23.0

  env -u PYTHONPATH python -m pip check
  python -c 'from importlib.metadata import version; print(version("vllm"))'
) 2>&1 | tee logs/20_vllm_install.log
```

验收版本为 `0.23.0+empty`。

图中是[vLLM-Ascend 官方源码安装](https://docs.vllm.ai/projects/ascend/en/v0.23.0/installation.html#set-up-using-python)里的 vLLM 主体示例。本实验沿用 `VLLM_TARGET_DEVICE=empty` 和 editable 安装方式，改用已核验的本地源码和离线选项。

![步骤 20：vLLM 主体的官方源码安装方式](official-screenshots/20-vllm-source.png)

### 21 编译安装 vLLM-Ascend 0.23.0.post1

编译目录使用已核对的插件源码和构建输入。实际芯片设置是 `ascend910b3`，自定义算子编译开启。CMake 和编译任务并行度设为 8。

```bash
(
  set -e
  sha256sum --check --quiet records/21_ascend_build_inputs_sha256.txt
  test -d src/vllm_ascend-0.23.0.post1/csrc/third_party/catlass/include

  export SOC_VERSION=ascend910b3 COMPILE_CUSTOM_KERNELS=1
  export MAX_JOBS=8 CMAKE_BUILD_PARALLEL_LEVEL=8
  export CC=/usr/bin/gcc CXX=/usr/bin/g++
  export C_COMPILER=/usr/bin/gcc CXX_COMPILER=/usr/bin/g++
  export CMAKE_GENERATOR="Unix Makefiles" VLLM_BATCH_INVARIANT=0

  python -m pip install --no-index --no-deps --no-build-isolation \
    --verbose --editable src/vllm_ascend-0.23.0.post1

  env -u PYTHONPATH python -m pip check
  python - <<'PY'
import json
from importlib.metadata import version
from pathlib import Path

import vllm_ascend.vllm_ascend_C
from vllm.platforms import current_platform

assert version("vllm-ascend") == "0.23.0.post1"
assert current_platform.device_type == "npu"
expected = json.loads(Path("records/19_core_before.json").read_text())
expected["vllm"] = "0.23.0+empty"
for package, pinned in expected.items():
    assert version(package) == pinned, package
Path("records/21_core_before.json").write_text(json.dumps(expected, indent=2))
print(type(current_platform).__name__)
PY
) 2>&1 | tee logs/21_vllm_ascend_install.log
```

原生扩展成功导入并显示 `NPUPlatform` 后，继续验证真实模型生成。

[vLLM-Ascend 官方源码安装](https://docs.vllm.ai/projects/ascend/en/v0.23.0/installation.html#set-up-using-python)给出插件的 editable 安装方式。本实验从缓存准备源码和构建依赖，编译设置见上方命令。

![步骤 21：vLLM-Ascend 插件的官方源码安装方式](official-screenshots/21-vllm-ascend-source.png)

### 22 做单卡真实生成

```bash
(
  set -e
  export ASCEND_RT_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1
  export VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_HOST_IP=127.0.0.1
  export HF_HUB_OFFLINE=1
  export TRITON_CACHE_DIR="$VERL_WORK/.cache/triton"
  export VLLM_CACHE_ROOT="$VERL_WORK/.cache/vllm"
  export TORCHINDUCTOR_CACHE_DIR="$VERL_WORK/.cache/torchinductor"
  mkdir -p "$TRITON_CACHE_DIR" "$VLLM_CACHE_ROOT" "$TORCHINDUCTOR_CACHE_DIR"
  python -u scripts/22_qwen35_vllm_check.py
) 2>&1 | tee logs/22_qwen35_vllm_check.log
```

本次在 NPU 0 上以 BF16、TP=1、Eager 模式运行两道短题并成功生成。结果见 `records/22_qwen35_vllm_result.json`。脚本会把回答、token 数和结束原因写入记录。[单卡生成脚本](22_qwen35_vllm_check.py)

### 23 安装 VERL 的训练依赖

本次准备了 47 个离线依赖文件。`fsspec` 锁定到 `2026.7.0`，`packaging` 锁定到 `25.0`，其余受保护的核心组件在脚本中逐项比对。验收涵盖 FSDP2 接口、Ray、TransferQueue、本地 Parquet、TensorBoard 和 vLLM 平台识别。[训练依赖锁](23_verl_deps.lock.txt) · [训练依赖验收脚本](23_check_training_dependencies.py)

```bash
(
  set -e
  (cd packages/23_verl_wheels && sha256sum --quiet -c ../../records/23_verl_wheels_sha256.txt)
  env -u PYTHONPATH python -m pip freeze --all > records/23_before_user_install.txt
  env -u PYTHONPATH python -m pip install --no-index --no-build-isolation \
    --find-links=packages/23_verl_wheels \
    -c records/23_verl_constraints.txt -r records/23_verl_deps.lock.txt
  env -u PYTHONPATH python -m pip check
  python -u scripts/23_check_training_dependencies.py
) 2>&1 | tee logs/23_verl_dependencies_install.log
```

从工作区同步时，`23_verl_deps.lock.txt` 放在服务器的 `records/`，`23_check_training_dependencies.py` 放在 `scripts/`。其余约束、包校验表和受保护版本快照随原实验材料迁移。

### 24 安装 VERL v0.9.1 源码

保留原始 sdist，校验 SHA256 `3e03d8816b2546b2c5580705671b8d0bb3f79b8364e7b5c56dbfc1245536ba22`。首次安装时将其解包到 `src/verl-0.9.1/`。准备脚本对照归档原件修改 `setup.py` 的 NumPy 依赖为 `numpy>=1.26.4,<2.0.0`，同时备份并记录差异。这是本地安装元数据适配。[准备脚本](24_prepare_verl_source.py) · [验收脚本](24_check_verl_install.py)

```bash
(
  set -e
  if ! test -f src/verl-0.9.1/setup.py; then
    printf '%s\n' '3e03d8816b2546b2c5580705671b8d0bb3f79b8364e7b5c56dbfc1245536ba22  packages/23_verl_sources/verl-0.9.1.tar.gz' \
      | sha256sum -c -
    tar -xzf packages/23_verl_sources/verl-0.9.1.tar.gz -C src
  fi
  env -u PYTHONPATH python -m pip freeze --all > records/24_before_install.txt
  python -u scripts/24_prepare_verl_source.py
  env -u PYTHONPATH python -m pip install --no-index --no-deps --no-build-isolation \
    --editable src/verl-0.9.1
  env -u PYTHONPATH python -m pip check
  python -u scripts/24_check_verl_install.py
) 2>&1 | tee logs/24_verl_install.log
```

通过后查看 `records/24_numpy_metadata.patch` 和 `records/24_verl_install_check.json`。后者记录训练入口预检所使用的包版本。

### 25 验证 Ray 八 Worker 调度

从第 10 步激活的八卡容器终端执行。此探针允许 Ray 设置各 Worker 的设备可见范围，再核对它们各自获得的 NPU 以及 Python 环境。[Ray 调度检查脚本](25_ray_check.py)

```bash
(
  unset RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES
  python -u scripts/25_ray_check.py
) 2>&1 | tee logs/25_ray_check.log
```

验收记录为 `records/25_ray_check.json`。调度探针通过后继续做真实集合通信。

### 26 验证八卡 HCCL

```bash
(
  set -e
  python -u scripts/26_hccl_check.py --preflight
  python -m torch.distributed.run --nnodes=1 --nproc-per-node=8 \
    --rdzv-backend=c10d --rdzv-endpoint=127.0.0.1:0 \
    --local-addr=127.0.0.1 --max-restarts=0 scripts/26_hccl_check.py
) 2>&1 | tee logs/26_hccl_check.log
```

各卡以 1–8 为输入时，AllReduce 期望值为 **36**。脚本覆盖 FP32、BF16 的集合通信，输出 `records/26_hccl_check.json`。[HCCL 检查脚本](26_hccl_check.py)

### 27 验证真实模型的八卡 FSDP2 参数更新

```bash
(
  set -e
  python -u scripts/26_hccl_check.py --preflight
  python -m torch.distributed.run --nnodes=1 --nproc-per-node=8 \
    --rdzv-backend=c10d --rdzv-endpoint=127.0.0.1:0 \
    --local-addr=127.0.0.1 --max-restarts=0 scripts/27_qwen35_fsdp2_check.py
) 2>&1 | tee logs/27_qwen35_fsdp2_check.log
```

该探针在真实模型上冻结视觉分支，完成短文本前向、反向和一次 AdamW 更新。通过条件包括裁剪前全局梯度范数有限且大于零，以及选定权重发生变化。结果见 `records/27_fsdp2_check.json`。[FSDP2 检查脚本](27_qwen35_fsdp2_check.py)

## 六、数据准备和基线评测

### 28 准备 GSM8K 并验证严格评分

原始数据固定在 `740312add88f781978c0658806c59bc2815b9866`。原训练集 7,473 条，用随机种子 42 抽出 256 条验证题，余下 7,217 条用于训练。官方测试集保留 1,319 条。模型回答以 `#### 数字` 提交最终答案，严格评分按数字与标准答案是否匹配给 1 分或 0 分。[GSM8K 数据](https://huggingface.co/datasets/openai/gsm8k) · [VERL 评分器](https://github.com/verl-project/verl/blob/v0.9.1/verl/utils/reward_score/gsm8k.py)

```bash
(
  set -e
  mkdir -p data/gsm8k/raw
  data_url='https://huggingface.co/datasets/openai/gsm8k/resolve/740312add88f781978c0658806c59bc2815b9866/main'
  for split in train test; do
    file="$split-00000-of-00001.parquet"
    if ! test -f "data/gsm8k/raw/$file"; then
      curl -fL --retry 3 -o "data/gsm8k/raw/$file.part" "$data_url/$file"
      mv "data/gsm8k/raw/$file.part" "data/gsm8k/raw/$file"
    fi
  done
  python -u scripts/28_prepare_gsm8k.py
) 2>&1 | tee logs/28_gsm8k_prepare.log
```

| 输出 | 条数 | 用途 |
|---|---:|---|
| `data/gsm8k/train.parquet` | 7,217 | GRPO 取题 |
| `data/gsm8k/val.parquet` | 256 | 训练中的验证 |
| `data/gsm8k/test.parquet` | 1,319 | 训练前后独立评测 |

预处理脚本还核验原始文件 SHA256、集合交叉情况、输入长度和奖励样例。输出 `records/28_gsm8k_data_check.json`，训练启动时会再核验转换后的文件哈希。[数据处理脚本](28_prepare_gsm8k.py) · [原始数据文件校验记录](28_gsm8k_official_metadata.json)

### 29 评测原始模型基线

以八卡分题运行，每卡一个 TP=1 的推理实例。每题生成一个回答，关闭 thinking，`temperature=0`，回答最多 1,024 tokens，使用同一严格评分规则。中断后可用同一模型路径和标签续跑。

```bash
python -u scripts/29_evaluate_gsm8k.py \
  --model "$VERL_WORK/models/Qwen3.5-0.8B" --label baseline \
  2>&1 | tee -a logs/29_gsm8k_baseline.log
```

基线得分 **636 / 1,319 = 48.22%**，格式符合率 **80.36%**，截断比例 **6.22%**。空回答和异常回答保留在总题数内。输出在 `eval/gsm8k/baseline/`，其中 `metrics.json` 是汇总，`predictions.jsonl` 是逐题结果，`run_config.json` 含评测协议及模型文件哈希。[评测脚本](29_evaluate_gsm8k.py)

## 七、GRPO 训练和权重导出

### 30 启动八卡 GRPO 并查看每步结果

| 配置 | 实际值 |
|---|---|
| 训练入口 | `verl.trainer.main_ppo`，V1 同步训练器 |
| 算法 | GRPO，规则打分，使用 Actor 和 Reference，禁用 Critic 网络 |
| Actor 与 Reference | FSDP2，Actor 参数与优化器状态留在设备侧，Reference BF16 |
| 生成 | vLLM-Ascend，TP=1，Eager，显存预算 0.25，纯文本且关闭 thinking |
| 每步数据 | 16 道题 × 每题 4 个回答，得到 64 个候选回答 |
| 长度和更新 | 输入最多 256 tokens，回答最多 1,024 tokens，学习率 `1e-6`，Actor KL 系数 `0.001` |
| 检查点和验证 | 目标 10 步，第 5、10 步保存，第 10 步使用 256 道验证题 |
| Ray 与日志 | 本地 Ray，64 个 CPU 调度资源、8 个 NPU，终端、JSONL 和 TensorBoard |

兼容设置在 [完整 YAML](30_grpo_config.yaml) 和 [配置生成脚本](30_run_grpo.py) 中。模型使用 Eager Attention，关闭去填充、融合算子、梯度检查点与 `torch.compile`。 [NPU 运行时模块](f00951948_npu_runtime.py) 由配置加载，用于设置 NPU 内部格式和 CPU 线程数。生成侧同样使用 Eager 模式，训练侧和生成侧通过权重同步衔接。

官方 `run_qwen3_0_6b_fsdp2_vllm_ascend.sh` 演示同一个 Python 入口，默认使用 Qwen3-0.6B、每题 5 个回答、TP=2。本实验使用上述 Qwen3.5 YAML、同一训练入口及单独的运行目录。[VERL 昇腾快速上手](https://verl.readthedocs.io/en/latest/ascend_tutorial/zh/get_start/quick_start.html)

#### 30A 使用本次实验封装生成配置并运行

前置条件为第 24、28、29 步通过。`--prepare-only` 检查环境、模型与数据哈希并生成 `config.yaml`。已有通过记录的同名运行会做结果核验，复跑可用 30B 的独立目录。

```bash
python -u scripts/30_run_grpo.py --steps 10 --run-name grpo10 --prepare-only
```

八卡空闲后正式执行。

```bash
python -u scripts/30_run_grpo.py --steps 10 --run-name grpo10 \
  2>&1 | tee -a logs/30_grpo_train.log
printf '训练退出码：%s\n' "${PIPESTATUS[0]}"
```

首次运行目录为 `runs/qwen35_grpo10/`。验收脚本逐步检查 1–10 步的 Loss 和梯度范数，并核对最后一步的 8 份模型、优化器、额外状态分片以及数据加载状态。验收文件是 `training_complete.json`，最终检查点为 `checkpoints/global_step_10/`。

#### 30B 手动调用官方 Python 入口

使用 30A 生成的 `runs/qwen35_grpo10/config.yaml`。新建一个手动运行目录，保留原始模型、数据及参数，把日志和检查点写到新目录。Ray 的 socket 路径另用短目录。

下图来自 [VERL 官方 Qwen3-0.6B 快速上手脚本](https://github.com/verl-project/verl/blob/main/tests/special_npu/quick_start/run_qwen3_0_6b_fsdp2_vllm_ascend.sh#L115-L123)。本实验沿用 `verl.trainer.main_ppo` 模块入口，模型、数据路径、并行度及训练步数按本实验配置。

![步骤 30B：VERL 官方快速上手脚本里的 Python 训练入口](official-screenshots/06-verl-entry.png)

```bash
export PYTHONPATH="$VERL_WORK/scripts${PYTHONPATH:+:$PYTHONPATH}"
export RAY_ENABLE_UV_RUN_RUNTIME_ENV=0 RAY_USAGE_STATS_ENABLED=0
VERL_RUN_NAME="qwen35_manual_$(date +%Y%m%d_%H%M%S)"
VERL_RUN_DIR="$VERL_WORK/runs/$VERL_RUN_NAME"
mkdir -p "$VERL_RUN_DIR/tensorboard" "$VERL_WORK/tmp/r33"

verl_cmd=(
  python -u -m verl.trainer.main_ppo
  --config-path="$VERL_WORK/runs/qwen35_grpo10"
  --config-name=config
  trainer.experiment_name="$VERL_RUN_NAME"
  trainer.total_training_steps=10
  trainer.resume_mode=disable
  trainer.default_local_dir="$VERL_RUN_DIR/checkpoints"
  trainer.rollout_data_dir="$VERL_RUN_DIR/rollouts"
  trainer.validation_data_dir="$VERL_RUN_DIR/validation"
  ray_kwargs.ray_init.namespace="$VERL_RUN_NAME"
  ray_kwargs.ray_init._temp_dir="$VERL_WORK/tmp/r33"
  ray_kwargs.ray_init.runtime_env.env_vars.TENSORBOARD_DIR="$VERL_RUN_DIR/tensorboard"
  ray_kwargs.ray_init.runtime_env.env_vars.VERL_FILE_LOGGER_PATH="$VERL_RUN_DIR/metrics.jsonl"
)

"${verl_cmd[@]}" --cfg job > "$VERL_RUN_DIR/config.yaml"
```

配置预览退出码为 0 后，在同一终端确认卡空闲并启动。

```bash
set -o pipefail
if python -u scripts/26_hccl_check.py --preflight; then
  "${verl_cmd[@]}" 2>&1 | tee -a "$VERL_RUN_DIR/train.log"
  printf '训练退出码：%s\n' "${PIPESTATUS[0]}"
fi
```

首次手动启动把时间戳实验名拼进了 Ray 临时路径。Ray 再追加会话目录和 `sockets/plasma_store` 后，实测路径长 120 字节，超过日志给出的 Unix socket 上限 107 字节。把临时目录改为 `/data1/f00951948_cann91/tmp/r33` 后，同样结构约 94 字节，后续重跑已推进到第 4 步。`--cfg job` 只解析配置，Ray 建链发生在实际启动时。

#### 第 4 步日志如何验收

手动重跑的日志同时给出 `training/global_step:4` 和 `4/10`。首轮封装训练的 10 步完成记录和这次手动重跑分别存档。

| 日志字段 | 第 4 步 | 说明 |
|---|---:|---|
| `actor/pg_loss` | 0.0375272 | Actor 的策略损失，有限值 |
| `actor/kl_loss`、`actor/kl_coef` | 0.000895723、0.001 | KL 项乘系数后计入 Actor 总损失 |
| `actor/loss` | 0.0375281 | 约等于策略损失加上加权 KL 项 |
| `actor/grad_norm`、`actor/lr` | 1.02106、1e-6 | 已产生有限的非零梯度，学习率符合配置 |
| `critic/score/mean` | 0.25 | 本批规则得分均值。在 64 个候选回答均有效、严格 0/1 计分时对应 16 个得 1 分 |
| `response_length/mean`、`max` | 638.98、1024 | 生成回答的平均与最大长度 |
| `response_length/clip_ratio` | 31.25% | 这批回答达到生成长度上限的比例 |
| `response/aborted_ratio` | 0 | 该步未记录中止生成 |
| `global_seqlen/minmax_diff` | 6,242 tokens | 平衡前各设备负载的最大差值 |
| `global_seqlen/balanced_min`、`balanced_max` | 5,867、5,893 tokens | 平衡后差值为 26 tokens |
| `training/rollout_actor_probs_pearson_corr` | 0.9996477 | 训练回算与生成概率的相关性 |
| `timing_s/gen`、`timing_s/update_actor` | 128.29 秒、31.52 秒 | 生成和 Actor 更新阶段耗时 |
| `timing_s/step`、`perf/total_num_tokens` | 179.93 秒、47,023 | 单步总耗时及处理的 token 数 |
| `perf/throughput` | 32.67 tokens/s/设备 | 按 47,023 ÷ 179.93 ÷ 8 计算 |
| `actor/perf/max_memory_allocated_gb`、`max_memory_reserved_gb` | 11.32、12.81 GiB | Actor 分配与预留显存峰值 |

`critic/score/*` 是框架沿用的日志字段，本实验的得分来自规则评分。`TransferQueueController` 输出的是样本和张量传输统计。`step:4` 及 Actor 更新指标说明训练循环已完成第 4 步的生成、评分和参数更新。模型提升由第 32 步在完整测试集上衡量。

### 31 合并 FSDP 检查点并核验导出权重

配套导出脚本读取 30A 的 `runs/qwen35_grpo10/training_complete.json` 及 `global_step_10/actor`。它核对八份模型分片，调用 VERL FSDP 合并接口，导出到 `models/Qwen3.5-0.8B-grpo-step10/`，并检查模型配置、权重张量及选定参数与原权重的差异。[本次导出脚本](31_export_grpo.py) · [VERL FSDP 合并接口](https://github.com/verl-project/verl/blob/v0.9.1/verl/model_merger/fsdp_model_merger.py)

```bash
python -u scripts/31_export_grpo.py 2>&1 | tee -a logs/31_export_grpo.log
```

导出验收记录为 `records/31_grpo_export_check.json`。若要评测 30B 的产物，需要指定那次运行的最终分片目录，并为它使用独立的导出目录和评测标签。当前的导出脚本固定指向 30A 的已验收检查点。

红框标的是 [VERL v0.9.1 的 FSDP 合并接口](https://github.com/verl-project/verl/blob/v0.9.1/verl/model_merger/fsdp_model_merger.py#L74-L82)。上方实验脚本封装 `FSDPModelMerger` 和 `merge_and_save()`，并增加分片、模型配置和权重张量核验。

![步骤 31：VERL 官方 FSDP 模型合并接口](official-screenshots/07-fsdp-export.png)

### 32 用同一协议复测并生成对比报告

重新加载导出的模型，评测同一批 1,319 题。对比脚本会核验基线和训练后评测的协议指纹、题目 ID、原题及标准答案，再计算准确率差值、错变对、对变错，以及配对检验。[对比脚本](32_compare_gsm8k.py)

```bash
(
  set -e
  python -u scripts/29_evaluate_gsm8k.py \
    --model "$VERL_WORK/models/Qwen3.5-0.8B-grpo-step10" --label grpo_step10
  python -u scripts/32_compare_gsm8k.py
) 2>&1 | tee -a logs/31_32_posttrain_eval.log
```

完成后，逐题结果在 `eval/gsm8k/grpo_step10/predictions.jsonl`，报告在 `records/32_grpo_gsm8k_comparison.json`。报告的提升单位是**百分点**。用训练后准确率减去同协议基线 `48.22%` 即可得到差值。

| 本次已留存的证据 | 对应结论 |
|---|---|
| 第 27 步真实模型权重变化 | 八卡 FSDP2 可以进行参数更新 |
| 原始模型测试集 `636/1319` | 同协议基线为 `48.22%` |
| 首次训练有第 1–10 步指标、检查点和完成记录 | 10 步 GRPO 训练与保存已验收 |
| 首次训练第 10 步的 256 题验证 | `154/256 = 60.16%`，这是训练内验证集成绩 |
| 手动重跑的 `step:4`、`4/10` | 直接使用官方 Python 入口的训练已推进到第 4 步 |
| 训练后 1,319 题完整对比报告 | 以 `32_grpo_gsm8k_comparison.json` 为准，当前整理依据未包含最终报告 |

## 排查与留档

| 现象 | 对应排查 |
|---|---|
| 找得到 `/data1/`，却加载到宿主机 CANN | 查看 `/.dockerenv`、`/etc/os-release`、`ASCEND_TOOLKIT_HOME`，进入目标容器并执行第 10 步 |
| `import acl`、`libatb.so` 或 NPU 初始化失败 | 先核对 CANN 与 ATB 环境脚本，再从第 10、12 步逐层复验 |
| 安装后 NumPy、PyTorch 或 Transformers 被升级 | 对照 `records/` 中的约束文件和安装报告，按第 19–24 步的离线依赖和适配记录恢复 |
| vLLM 能导入，初始化模型时失败 | 核对 `NPUPlatform`、原生扩展、模型权重哈希，先执行第 22 步 |
| Ray 报 `AF_UNIX path length cannot exceed 107 bytes` | 用 `tmp/r33` 作为 Ray 临时目录，运行目录继续使用完整实验名 |
| 八卡任务停在通信或等待 Worker | 先做第 25、26 步，核对卡占用、Ray 资源和各 Rank 的报错 |
| 训练日志含 `Disabled critic` 或 `critic/score/mean` | 结合 GRPO 配置解读，规则评分提供奖励，Actor 和 Reference 参与本次更新流程 |
| 看到 `step:4`，需要确认训练结束 | 查同一运行目录的 `step:10`、退出码与 `global_step_10` 检查点。使用封装时再核对 `training_complete.json` |

保存环境时，以 `packages/`、`src/`、`scripts/`、`records/`、`logs/`、模型权重、数据和训练产物为准。Conda 的显式包清单与 pip 版本记录可分别通过下列命令补存。

```bash
conda list --explicit > records/conda_final_packages.txt
env -u PYTHONPATH python -m pip freeze --all > records/pip_freeze_final.txt
env -u PYTHONPATH python -m pip check
```
